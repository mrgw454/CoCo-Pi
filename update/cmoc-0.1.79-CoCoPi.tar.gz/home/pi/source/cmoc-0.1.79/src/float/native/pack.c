#include "floatable.h"


void
floatable_pack(PFloat40 *dest, const UFloat40 *src)
{
    memcpy(dest, src, 5);  // exponent and mantissa
    byte *highByte = &dest->mant[0];
    *highByte = *highByte & 0x7F | (src->sign ? 0x80 : 0x00);
}
