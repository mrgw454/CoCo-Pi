#include "floatable-private.h"


asm __norts__ void
floatable_addUFloat40(UFloat40 *fp0, const UFloat40 *fp1)
{
    asm
    {
_fadd           IMPORT
        pshs    u
        ldx     4,s     ; fp0
        ldu     6,s     ; fp1
        lbsr    _fadd
        puls    u,pc
    }
}
