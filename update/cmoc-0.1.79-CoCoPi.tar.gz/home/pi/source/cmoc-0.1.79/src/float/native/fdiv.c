#include "floatable-private.h"


byte
floatable_divUFloat40(UFloat40 *dividend, const UFloat40 *divisor)
{
    //printf("# fdiv: dividend->biasedExp=$%02x, divisor->biasedExp=$%02x\n", dividend->biasedExp, divisor->biasedExp);

    if (dividend->biasedExp == 0)
    {
        memset(dividend, 0, sizeof(UFloat40));
        return 0;  // success
    }

    dividend->sign = (dividend->sign ^ divisor->sign);
    //printf("# fdiv: quotient sign: $%02x\n", dividend->sign);

    // Check for an invalid operation.
    if (divisor->biasedExp == 0)
    {
        //printf("# fdiv: /0\n");
        // Return the highest possible value.
        * (dword *) dividend->mant = 0xFFFFFFFFul;
        dividend->biasedExp = BIAS + 127;
        return 1;  // division by zero
    }

    // Compute the quotient's sign and exponent.
    int quotientExp = (int) (char) (dividend->biasedExp - BIAS) - (int) (char) (divisor->biasedExp - BIAS);

    byte quotientMant[5];
    byte dividendMant[5];
    * (dword *) dividendMant = * (dword *) dividend->mant;
    dividendMant[4] = 0;
    byte numShiftsBeforeFirstSetBit;  // will be either 31 or 32
    div40by32(quotientMant, &numShiftsBeforeFirstSetBit,
                dividendMant, divisor->mant);

    //printf("# fdiv: quotientMant: %02x %02x %02x %02x %02x\n",
             //quotientMant[0], quotientMant[1], quotientMant[2], quotientMant[3], quotientMant[4]);

    //printf("# fdiv: numShiftsBeforeFirstSetBit=%u\n", numShiftsBeforeFirstSetBit);
    //printf("# fdiv: exponents: $%02x - $%02x\n",
            //dividend->biasedExp, divisor->biasedExp);
    int finalExp =   ((int) ((char) dividend->biasedExp - BIAS))
                   - ((int) ((char) divisor->biasedExp  - BIAS))
                   + (numShiftsBeforeFirstSetBit == 31);  // 0 or 1
    //printf("# fdiv: finalExp=%d\n", finalExp);
    if (finalExp < -127 || finalExp > 127)
        return 2;  // overflow
    dividend->biasedExp = (byte) finalExp + BIAS;

    //printf("# fdiv: new exponent: $%02x\n", dividend->biasedExp);
    * (dword *) dividend->mant = * (dword *) quotientMant;

    return 0;  // success
}
