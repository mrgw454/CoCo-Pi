#include "floatable-private.h"


#ifndef NDEBUG


BOOL
_assert(BOOL evaluatedCondition, const char *conditionExpr, const char *fn, int line)
{
    if (evaluatedCondition)
        return TRUE;
    printf("ERROR at line %s:%d: Condition \"%s\" failed\n", fn, line, conditionExpr);
    exit(1);
}


BOOL
_assert_eq_str(const char *actual, const char *expected, const char *fn, int line)
{
    if (!strcmp(actual, expected))
        return TRUE;
    printf("ERROR at line %s:%d: Got string '%s', expected '%s'\n", fn, line, actual, expected);
    exit(1);
}


#endif
