#include "floatable-private.h"


// Returns -1 if acc < divisor, 0 if equal, +1 if acc > divisor.
//
asm __norts__ char
compareAccWithDivisor(const byte acc[5], const byte divisor[4])
{
    asm
    {
        pshs    u
        ldx     4,s             ; acc
        ldu     6,s             ; divisor
        tst     ,x              ; acc[0]
        bne     @accIsGreater
        ldd     1,x             ; acc[1..2]
        cmpd    ,u              ; divisor[0..1]
        bhi     @accIsGreater
        blo     @accIsSmaller
        ldd     3,x             ; acc[3..4]
        cmpd    2,u             ; divisor[2..3]
        bhi     @accIsGreater
        blo     @accIsSmaller
        clrb
        bra     @return
@accIsSmaller
        ldb     #-1
        bra     @return
@accIsGreater
        ldb     #1
@return
        puls    u,pc
    }
}
