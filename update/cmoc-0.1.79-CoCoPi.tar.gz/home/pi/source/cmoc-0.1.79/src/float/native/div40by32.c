#include "floatable-private.h"

// Trashes dividend[].
//
void
div40by32(byte quotient[5], byte *numShiftsBeforeFirstSetBit,
          byte dividend[5], const byte divisor[5])
{
    //printf("# div40by32: start\n");
    byte acc[5] = { 0, 0, 0, 0, 0 };

    BOOL seenFirstSetBit = FALSE;
    *numShiftsBeforeFirstSetBit = 0;

    for (byte numBitsNeeded = 40; numBitsNeeded > 0; )
    {
        //printf("#   n=%2u. quotient=%02x %02x %02x %02x %02x\n",
        //        numBitsNeeded, quotient[0], quotient[1], quotient[2], quotient[3], quotient[4]);
        //printf("#         dividend=%02x %02x %02x %02x %02x\n",
        //        dividend[0], dividend[1], dividend[2], dividend[3], dividend[4]);

        byte shiftedBit = shift5BytesLeft1Bit(dividend, 0);
        shift5BytesLeft1Bit(acc, shiftedBit);
        //printf("#              acc=%02x %02x %02x %02x %02x\n",
        //         acc[0], acc[1], acc[2], acc[3], acc[4]);
        char cmpResult = compareAccWithDivisor(acc, divisor);
        //printf("#        cmpResult=%d\n", cmpResult);
        if (cmpResult >= 0)  // if acc >= divisor, i.e., divisor fits in acc
        {
            subtract32From40(acc, divisor);  // acc -= divisor
            seenFirstSetBit = TRUE;
        }
        if (seenFirstSetBit)
        {
            shift5BytesLeft1Bit(quotient, cmpResult >= 0);
            --numBitsNeeded;
        }
        else
            ++*numShiftsBeforeFirstSetBit;
    }
    //printf("#   end:  quotient=%02x %02x %02x %02x %02x, numShiftsBeforeFirstSetBit=%u\n",
    //        quotient[0], quotient[1], quotient[2], quotient[3], quotient[4],
    //        *numShiftsBeforeFirstSetBit);
}
