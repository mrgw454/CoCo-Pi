#include "floatable.h"


void floatable_unpack(UFloat40 *dest, const PFloat40 *src)
{
    memcpy(dest, src, 5);  // exponent and mantissa
    byte *highByte = &dest->mant[0];
    dest->sign = (*highByte & 0x80) ? 0xFF : 0x00;
    if (src->biasedExp != 0)  // if number is not 0.0
        *highByte |= 0x80;
}
