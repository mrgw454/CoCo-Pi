#include "floatable-private.h"


// Determines if a leading zero is written in the decimal representation
// of a number between -1 and +1 when using convention (non-scientific) notation.
// Example: FALSE gives ".5" (as with Color Basic), TRUE gives "0.5".
//
static BOOL leadingZeroOnSubOneNonSciNotation = FALSE;


typedef struct NegativePowerOf2
{
    const char *digits;
    char powerOf10;
} NegativePowerOf2;


// Decimal representations of powers of 2.
//
static const NegativePowerOf2 negativePowersOf2[] =
{
    { "5000000000",  0 },
    { "2500000000",  0 },
    { "1250000000",  0 },
    { "6250000000", -1 },  // e.g., .625 * 10^-1 = .0625 = 2^-4 = 1/16
    { "3125000000", -1 },
    { "1562500000", -1 },
    { "7812500000", -2 },
    { "3906250000", -2 },
    { "1953125000", -2 },
    { "9765625000", -3 },
    { "4882812500", -3 },
    { "2441406250", -3 },
    { "1220703125", -3 },
    { "6103515625", -4 },
    { "3051757812", -4 },
    { "1525878906", -4 },
    { "7629394531", -5 },
    { "3814697265", -5 },
    { "1907348632", -5 },
    { "9536743164", -6 },
    { "4768371582", -6 },
    { "2384185791", -6 },
    { "1192092895", -6 },
    { "5960464477", -7 },
    { "2980232238", -7 },
    { "1490116119", -7 },
    { "7450580596", -8 },
    { "3725290298", -8 },
    { "1862645149", -8 },
    { "9313225746", -9 },
    { "4656612873", -9 },
    { "2328306436", -9 },
};


// Equivalent of decAcc += 0.digits * 10**powerOf10.
// powerOf10: Must be <= 0.
//
void
addToDecAcc(char decAcc[DEC_ACC_WIDTH + 1], const char digits[DEC_ACC_WIDTH + 1], char powerOf10)
{
    //printf("# addToDecAcc: start: decAcc=%s, digits=%s, powerOf10=%d\n", decAcc, digits, powerOf10);
    
    // Example: decAcc=6398925781, digits=6103515625, powerOf10=-4
    //    0123456789 <- indices in decAcc
    //   .6398925781 <- decAcc
    // + .00006103515625 <- digits, shifted according to powerOf10
    //        0123456789 <- indices in digits
    byte decAccIndex = DEC_ACC_WIDTH;  // index into decAcc
    assert(powerOf10 > -DEC_ACC_WIDTH);
    char digitsIndex = /*(byte)*/ (DEC_ACC_WIDTH + powerOf10);  // index into digits
    byte carry = (digitsIndex == DEC_ACC_WIDTH ? 0 : (digits[digitsIndex] >= '5'));
    assert_bool_value(carry);
    for ( ; decAccIndex--; )  // for each digit in decAcc
    {
        char digit = (digitsIndex > 0 ? digits[--digitsIndex] - '0' : 0);
        byte newDecAccDigit = (decAcc[decAccIndex] - '0') + digit + carry;
        /*printf("#   %u, %u: %u + %u + %u = %2u\n",
                decAccIndex, digitsIndex,
                decAcc[decAccIndex] - '0', digit, carry, newDecAccDigit);*/
        decAcc[decAccIndex] = '0' + (newDecAccDigit > 9 ? newDecAccDigit - 10 : newDecAccDigit);
        carry = (newDecAccDigit > 9);
        assert_bool_value(carry);
    }

    //printf("# addToDecAcc: end  : decAcc=%s\n", decAcc);
}


// Multiply the value of the decimal accumulator in decAcc[0..9] by two.
//
static BOOL
doubleDecAcc(char decAcc[DEC_ACC_WIDTH])
{
    byte carry = 0;
    for (byte i = DEC_ACC_WIDTH; i--; )
    {
        char doubledDigit = (decAcc[i] - '0') * 2 + carry;
        carry = (doubledDigit > 9);
        decAcc[i] = (carry ? doubledDigit - 10 : doubledDigit) + '0';
    }
    if (!carry)
        return FALSE;
    // Move all digits but one to the right and insert a 1 at left.
    for (byte i = 9; i--; )
        decAcc[i + 1] = decAcc[i];
    decAcc[0] = '1';
    return TRUE;
}


// Divide the value of the ASCII decimal accumulator in decAcc[0..9] by two,
// then, if the leftmost place is 0, shift the accmulator left by one place.
// Returns TRUE iff decAcc[] got shifted left.
// Example: "124" becomes "062", which gets shifted to "620".
// Example: "444" becomes "222", which does not get shifted.
//
BOOL
halveDecAcc(char decAcc[DEC_ACC_WIDTH])
{
    //printf("#  halveDecAcc: start: %s\n", decAcc);
    // Divide each digit, from left to right, by 2.
    // If that gives a remainder of 1, carry it to the following digit.
    byte carry = 0;  // 0 or 10
    byte i;
    for (i = 0; i < DEC_ACC_WIDTH; ++i)  // for each digit from left to right
    {
        char digit = decAcc[i] - '0';
        decAcc[i] = '0' + ((carry + digit) >> 1);
        carry = (digit & 1) ? 10 : 0;
    }
    assert(decAcc[0] <= '4');
    if (carry)
    {
        // Dividing decAcc[] by 2 gave a remainder of 1. Round up, then if the rounded up value
        // does not require left-shifting, return it; otherwise, don't round up, and continue.
        // Example: "101" gives "050" with remainder of 1, so we want "051" (50.5 rounded up).
        //
        //printf("#  halveDecAcc: rounding up %s\n", decAcc);
        char roundedUpAcc[DEC_ACC_WIDTH + 1];
        memcpy(roundedUpAcc, decAcc, DEC_ACC_WIDTH);
        assert(i == DEC_ACC_WIDTH);
        for ( ; i--; )  // from rightmost digit to leftmost one
        {
            char *pDigit = roundedUpAcc + i;  // point to the current digit
            if (++*pDigit <= '9')  // if no carry
                break;
            *pDigit = '0';
        }
        //roundedUpAcc[DEC_ACC_WIDTH] = '\0';
        //printf("#  halveDecAcc: roundedUpAcc: %s\n", roundedUpAcc);
        if (roundedUpAcc[0] != '0')  // if no left-shifting required, use rounded up value as final one
            memcpy(decAcc, roundedUpAcc, DEC_ACC_WIDTH);
    }
    if (decAcc[0] != '0')
    {
        //printf("#  halveDecAcc: %c, carry=%u -> no shift -> %s\n", decAcc[0], carry, decAcc);
        return FALSE;  // no shifting needed
    }

    // The leftmost digit is 0, so decAcc[] needs to be shifted left.

    // Move all digits but one to the left, then, if there is a carry, insert a 5 at the right.
    // Example: decAcc[] was originally "105" and got divided by 2, giving "052" with a carry,
    //          then rounding up gave "053".
    //          We rejected this "053" because of the 0 in the leftmost position.
    //          We thus take the unrounded "052", we shift it left, giving "52_",
    //          then put a 5 at the right because there is a carry in this case, giving "525".
    //          This means that .105 / 2 = .525 / 10.
    //
    for (byte i = 1; i < DEC_ACC_WIDTH; ++i)
        decAcc[i - 1] = decAcc[i];
    decAcc[DEC_ACC_WIDTH - 1] = (carry ? '5' : '0');
    //printf("#  halveDecAcc: shift: %s\n", decAcc);
    return TRUE;
}


// Converts 'number' to two ASCII digits in 'dest'.
//
static void
write2Digits(char *dest, byte number)
{
    *dest++ = '0' + number / 10;
    *dest++ = '0' + number % 10;
}


// Copies the suffix of 'dest' that starts with the first 'E' to 'dest'.
// The resulting string is NUL-terminated.
// If no 'E' is found, 'dest' becomes an empty string.
//
static void
removeBeforeE(char *dest)
{
    char *e = strchr(dest, 'E');
    if (e)
        while (*e)
            *dest++ = *e++;
    *dest = '\0';
}


// If a point is found in ASCII number 'dest', removes trailing zeroes in
// the fractional part. Example: "-1.23000E45" becomes "-1.23E45".
//
static void
removeTrailingZeroesAfterPoint(char *dest)
{
    char *point = strchr(dest, '.');
    if (!point)
        return;
    char *lastNonZeroDigit = NULL, *p;
    for (p = point + 1; *p != '\0' && *p != 'E'; ++p)
        if (*p != '0')
            lastNonZeroDigit = p;
    // printf("# removeTrailingZeroesAfterPoint: dest='%s', p='%s', lastNonZeroDigit='%s'\n",
    //             dest, p, lastNonZeroDigit);
    if (lastNonZeroDigit)
        removeBeforeE(lastNonZeroDigit + 1);
    else  // only zeroes after point, so fractional part useless
        removeBeforeE(point);
}


// dest: Must contain a decimal number to be rounded.
//       Must be NUL-terminated.
//       Gets modified in place.
// numSignificantDigits: Number of digits after which the rounding must be done.
// Assumes that a number between -1 and 1 has a zero before
// the decimal point, e.g., "0.5" instead of ".5".
//
void
roundDecimalString(char dest[], byte numSignificantDigits)
{
    //printf("# roundDecimalString('%s', %u)\n", dest, numSignificantDigits);
    char *writer = dest;
    if (*writer == '-')
        ++writer;
    if (*writer == '0')
        ++writer;
    BOOL atRightOfPoint = FALSE;
    for ( ; numSignificantDigits > 0; ++writer)
    {
        if (*writer == '\0' || *writer == 'E')
            break;
        if ((BOOL) isdigit(*writer))  // *writer may be the decimal point, just pass it
            --numSignificantDigits;
        else if (*writer == '.')
            atRightOfPoint = TRUE;
    }
    if (!atRightOfPoint)  // if decimal point not seen, then fractional part not reached
        return;  // do nothing
    assert(writer > dest);

    //printf("# roundDecimalString: writer at index %u: '%s'\n", writer - dest, writer);
    //printf("# roundDecimalString: dest: %s\n", dest);

    // Must round digits at left of 'writer' according to digit at 'writer', if any.
    if (*writer == '\0' || *writer == 'E')  // no more digits
    {
        //printf("# roundDecimalString: no more digits\n");
        return;  // nothing to do
    }
    // We have seen the point, so *writer is a digit.
    assert((BOOL) isdigit(*writer));
    BOOL roundUp = (*writer >= '5');
    // New end of string at 'writer' unless zeroes appear at its left while rounding up.
    //printf("# roundDecimalString: roundUp=%u b/c %c\n", roundUp, *writer);
    if (!roundUp)
    {
        //printf("# roundDecimalString: calling removeBeforeE on '%s'\n", writer);
        removeBeforeE(writer);
        //printf("# roundDecimalString: after removeBeforeE: dest: %s\n", dest);
        removeTrailingZeroesAfterPoint(dest);
        return;
    }
    
    for (char *prev = writer - 1; ; --prev)
    {
        //printf("# roundDecimalString: prev at index %u sees char %c\n", prev - dest, *prev);
        // Find previous digit.
        BOOL reachedStart = FALSE;
        for ( ; ; --prev)
        {
            if (prev < dest || *prev == '-')
            {
                reachedStart = TRUE;
                break;
            }
            if ((BOOL) isdigit(*prev))
                break;
            if (*prev == '.')
                atRightOfPoint = FALSE;
        }
        if (reachedStart)
        {
            //printf("# roundDecimalString:   reached start\n");

            // Example: We are rounding up "-99.9". prev now points to the minus sign.
            //          Push the digits, which are now zeroes one place to the right
            //          and prepend them with a 1.
            //          The fractional part is discarded because it is all zeroes.

            // First, find the end of the integer part.
            char *intPartEnd = (prev < dest ? dest : prev);
            while (*intPartEnd && *intPartEnd != '.' && *intPartEnd != 'E')
                ++intPartEnd;
            // Find the start and end of the exponential part (e.g, "E-12").
            // The start and end are both at EOS if no exponential part.
            char *expPartStart = intPartEnd;
            while (*expPartStart && *expPartStart != 'E')
                ++expPartStart;
            //printf("# roundDecimalString:     expPartStart='%s'\n", expPartStart);
            
            // Keep a copy of the exp. part.
            char expPartCopy[5];  // longest case: "E-11"
            strcpy(expPartCopy, expPartStart);
            
            // Disregarding the exp. part in 'dest', move the zeroes of the integer part to the right.
            *intPartEnd = '0';
            prev[1] = '1';
            
            // Restore the exp. part.
            char *e = intPartEnd + 1;
            strcpy(e, expPartCopy);
            e[strlen(expPartCopy)] = '\0';
            
            break;  // done
        }
        //printf("# roundDecimalString:   found digit at %u: %c\n", prev - dest, *prev);
        ++*prev;
        if (*prev <= '9')  // if no carry, done
        {
            if (atRightOfPoint)
                removeBeforeE(prev + 1);
            else
            {
                // Example: 987.9997 rounded at 6 digits gives 988.000.
                // atRightOfPoint == FALSE means that we have incremented the integer part,
                // so the fractional part must be all zeroes. Get rid of the fractional part.
                char *point = strchr(prev, '.');
                if (point)
                    removeBeforeE(point);
            }
            break;  // done
        }
        // Carry to the digit at left, and continue with the digit at the left.
        *prev = '0';
    }
    
    //printf("# roundDecimalString: end: dest: %s\n", dest);
}


// Converts an integer which is larger than the 32-bit mantissa to ASCII decimal.
// writer: Address where to write the ASCII decimal digits and the E## suffix.
// exp: Binary exponent, which must be larger than 32.
// ulongMant: Mantissa of the original floating point accumulator, i.e., the high bit is 1.
// Returns the address where 'writer' advanced.
//
static char *
toDecimalLargeIntegerNoFraction(char writer[DEC_ACC_WIDTH + 5],
                                char exp,
                                unsigned long ulongMant)
{
    assert(exp > 32);
    //printf("# toDecimalLargeIntegerNoFraction: ulongMant=$%lx ($%lx, $%lx)\n", ulongMant, 0x80000000UL, ulongMant & 0x80000000UL);
    assert((ulongMant & 0x80000000UL) != 0);

    char decAcc[DEC_ACC_WIDTH + 1];

    // Write the mantissa as a 10-digit decimal number in decAcc[], with zero left-padding.
    // ulongMant is at least 0x80000000 (2147483648), because its leftmost bit is 1.
    // ulongMant is at most 2^32-1 (4294967295). This means ulongMant has 10 decimal digits.
    //
    ultoa10(ulongMant, decAcc);  // writes 10 digits, finishes with '\0'
    
    // The integer part is larger than the mantissa, so double decAcc until exp is down to 32.
    // Increment the power of 10 as needed.
    //printf("#   start: exp=%d, decAcc=%s\n", exp, decAcc);
    byte powerOf10 = 9;  // smallest number in this case is 4.294967295E9
    do
    {
        BOOL carry = doubleDecAcc(decAcc);
        //printf("#   exp=%d, decAcc=%s, carry=%u, powerOf10=%u\n", exp, decAcc, carry, powerOf10);
        if (carry)  // if carry
            ++powerOf10;
    } while (--exp > 32);

    // Copy result to final string, with decimal point after 1st digit.
    byte j = 0;
    for ( ; decAcc[j] == '0'; ++j)  // find 1st non-0 digit
        ;
    j = 9 - j;  // limit precision to 9 digits to avoid differences wrt other float libs
    if (j > 0)
    {
        *writer++ = decAcc[0];
        if (j > 1)
        {
            *writer++ = '.';
            --j;
            memcpy(writer, decAcc + 1, j);  // writes at most DEC_ACC_WIDTH chars
            writer += j;
        }
    }
    // At most DEC_ACC_WIDTH + 2 chars written at this point.
    *writer++ = 'E';
    write2Digits(writer, powerOf10);
    return writer + 2;  // At most DEC_ACC_WIDTH + 5 chars written at this point.
}


// Rotate byte variable 'mask' right one bit (not through carry).
// 'mask' is assumed to contain a single set bit.
// If the set bit is rotated back to bit 7, 'bytePtr' is incremented.
//
#define WALK(mask, bytePtr) do { if (!((mask) >>= 1)) { (mask) = 0x80; ++(bytePtr); } } while (FALSE)


// writer: Destination buffer. Receives ASCII characters. Does not receive a terminating '\0'.
// origMantBytePtr: Address of the 32-bit mantissa of the original FP accumulator.
// exp: Binary exponent.
// Returns the address past the last character written.
//
static char *
toDecimalFractionalPart(char writer[DEC_ACC_WIDTH + 6],
                        const byte *origMantBytePtr,
                        char exp)
{
    //printf("# toDecimalFractionalPart: start: origMantBytePtr=%p, exp=%d\n", origMantBytePtr, exp);

    // Initialize a decimal accumulator that will accumulate the fraction.
    //
    char decAcc[DEC_ACC_WIDTH + 1];
    memset(decAcc, '0', DEC_ACC_WIDTH);
    decAcc[DEC_ACC_WIDTH] = '\0';  // helps when tracing with printf's %s

    // Point to the first bit of the fractional part in the mantissa.
    // Example: 5.5f is .1011 * 2^3, so 'mask' will become 0x80 >> 3, i.e., 0x10.
    //          This mask corresponds to the rightmost '1' in .1011, which is the
    //          first bit of the fractional part.
    //          origMantBytePtr does not get advanced in this case because that
    //          first bit is in the first byte of the mantissa.
    //
    byte mask = 0x80;
    const char nonNegExp = exp < 0 ? 0 : exp;
    for (byte e = nonNegExp; e; --e)
        WALK(mask, origMantBytePtr);
    
    // For each bit that is set in the fractional part, add the corresponding
    // power of 2 to decAcc[].
    // Example: 0.625f is .101 * 2^0. First leftmost 1 in .101 is 2^-1 and the
    //          rightmost 1 in .101 is 2^-3, so we add .500 and .125 and get .625.
    //
    //printf("# toDecimalFractionalPart: mask=$%02X, origMantBytePtr=%p ($%02X)\n",
    //        mask, origMantBytePtr, *origMantBytePtr);
    for (char bitCounter = nonNegExp; bitCounter < 32; ++bitCounter)  // for each bit of frac. part
    {
        byte isBitSet = !!(*origMantBytePtr & mask);
        //printf("# toDecimalFractionalPart:  bitCounter=%2u: %p $%02X->%u\n",
        //            bitCounter, origMantBytePtr, *origMantBytePtr, isBitSet);
        if (isBitSet)
        {
            const byte powerOf2Index = (byte) (bitCounter - nonNegExp);  // never negative
            /*printf("# toDecimalFractionalPart:    powerOf2Index=%d: %s 10^%d\n",
                        powerOf2Index,
                        negativePowersOf2[powerOf2Index].digits,
                        negativePowersOf2[powerOf2Index].powerOf10);*/

            //char origDecAcc[DEC_ACC_WIDTH + 1];
            //memcpy(origDecAcc, decAcc, DEC_ACC_WIDTH + 1);

            const NegativePowerOf2 *np2 = &negativePowersOf2[powerOf2Index];
            addToDecAcc(decAcc, np2->digits, np2->powerOf10);
            /*printf("# toDecimalFractionalPart:    added power of 2 (.%s e%3d), now decAcc is 0.%s\n",
                        np2->digits, np2->powerOf10, decAcc);
            {
                printf("    .%s\n", origDecAcc);
                printf("  + .");
                for (char p = np2->powerOf10; p < 0; ++p)
                    putchar('0');
                byte i = 0;
                for (char p = DEC_ACC_WIDTH + np2->powerOf10; p--; ++i)
                    putchar(np2->digits[i]);
                putchar(' ');
                for ( ; i < DEC_ACC_WIDTH; ++i)
                    putchar(np2->digits[i]);
                printf(" (1/2**%u)\n", powerOf2Index + 1);
                printf("  = .%s\n", decAcc);
            }*/
            assert_eq(strchr(decAcc, '/'), 0);
        }

        // Advance 'mask' (and possibly 'origMantBytePtr' to correspond with 'bitCounter').
        WALK(mask, origMantBytePtr);
    }
    
    // If the number only has a fractional part and the point is at the left
    // of the mantissa, divide decAcc[] by 2 as many times as specified by 'exp'.
    // Some divisions by 2 may cause a left-shift of decAcc, which must be compensated
    // by decrementing the power of 10 applied to decAcc later.
    //
    char negPowerOf10 = 0;
    if (exp < 0)
    {
        // Example: 0.0625f is .1 * 2^-3. The binary .1 is .5 in decimal, and it gets
        //          divided by two 3 times: .5 / 2 / 2 / 2 = 0.0625.
        //
        negPowerOf10 = 1;
        for (char c = exp ; c < 0; ++c)
        {
            BOOL shifted = halveDecAcc(decAcc);
            if (shifted)
                ++negPowerOf10;
            //printf("#   c=%3d: halved: %s, shifted=%u, 10**%3d\n", c, decAcc, shifted, -negPowerOf10);
        }
    }

    // Add fractional part at 'writer' if at least one digit is non zero.
    //
    byte indexOfLastNonZeroDigit;  // index in decAcc[], or 255 if all zeroes in decAcc[]
    for (indexOfLastNonZeroDigit = DEC_ACC_WIDTH; indexOfLastNonZeroDigit--; )
        if (decAcc[indexOfLastNonZeroDigit] != '0')
            break;
    //printf("# toDecimalFractionalPart: decAcc=%s; indexOfLastNonZeroDigit=%u, negPowerOf10=%u\n",
    //       decAcc, indexOfLastNonZeroDigit, negPowerOf10);
    if (indexOfLastNonZeroDigit != 0xFF)  // if at least one non-zero digit in decAcc[]
    {
        byte n = indexOfLastNonZeroDigit;  // number of digits to be copied from decAcc[]
        const BOOL useSciNotation = (negPowerOf10 >= 3);
        if (useSciNotation)
        {
            // Write first decimal digit before upcoming decimal point.
            *writer++ = decAcc[0];
            // 'n' stays the same, to exclude that first digit from the upcoming copy,
            // which will start at decAcc[1].
        }
        else
        {
            if (leadingZeroOnSubOneNonSciNotation && exp <= 0)
                *writer++ = '0';
            ++n;  // add one to include digit at decAcc[indexOfLastNonZeroDigit]
        }
        // At most 1 char written at this point.

        if (n > 0)  // if some digits in decAcc[] left to be copied
        {
            *writer++ = '.';
            // printf("# toDecimalFractionalPart: wrote decimal point; n=%u, negPowerOf10=%u, decAcc='%s'\n",
            //         n, negPowerOf10, decAcc);
            if (!useSciNotation)
            {
                assert(negPowerOf10 < 3);  // following loop writes at most 1 char
                for (byte z = negPowerOf10; z > 1; --z)  // write leading zeroes after point
                    *writer++ = '0';
            }
            // At most 2 chars written at this point.

            memcpy(writer, decAcc + !!useSciNotation, n);  // copy starts reading at decAcc[0] or decAcc[1]
            writer += n;
            //*writer = '\0'; printf("# toDecimal: dest is now: %s\n", dest);

            // At most DEC_ACC_WIDTH + 2 chars written at this point.
        }
        
        if (useSciNotation)
        {
            * (word *) writer = 0x452D;  // write "E-"
            writer += 2;
            write2Digits(writer, negPowerOf10);
            writer += 2;
        }
    }

    // At most DEC_ACC_WIDTH + 6 chars written at this point.
    return writer;
}


#undef WALK
#define WALK(mask, bytePtr)


void
floatable_toDecimal(char dest[DEC_ACC_WIDTH + 18], const UFloat40 *num)
{
    // Zero case.
    //
    if (num->biasedExp == 0)
    {
        dest[0] = '0';
        dest[1] = '\0';
        return;
    }

    char *writer = dest;
    const char exp = (char) (num->biasedExp - BIAS);  // -127..127
    //printf("# toDecimal: biasedExp=%u -> exp=%d\n", num->biasedExp, exp);

    // Process the sign.
    //
    if (num->sign)
        *writer++ = '-';

    // At most 1 char written at this point.

    // Make a copy of the mantissa and, if num has a non-zero integer part that
    // fits in 32 bits, shift the copied mantissa right by 32 - exp bits.
    // This makes mant[] represent the integer part of 'num'.
    // Example: 5.0f is .101 * 2^3, so num->mant[] is 1010000...0.
    //          By shifting this right by 29 bits (32 - 3), we get 000...000101.
    // Example: 5e9f has an exponent of 33, so we know that 5e9 does not fit in 32 bits.
    // Example: 0.5f is .1 * 2^0 and 0.25f is .1 * 2^-1, so because exp <= 0, we know
    //          there is no integer part.
    //
    byte mant[4];
    copyMantissa(mant, num->mant);
    if (exp > 0 && exp < 32)
    {
        asm
        {
rightShiftMantissa IMPORT
            leax    :mant
            lda     #32
            suba    :exp
            lbsr    rightShiftMantissa
        }
    }

    // View the (possibly shifted) mantissa as an unsigned 32-bit integer.
    unsigned long ulongMant = * (unsigned long *) mant;

    if (exp <= 32)  // if there is an integer part that fits 32 bits, or no integer part
    {
        if (exp > 0)  // if there is an integer part
        {
            ultoa10(ulongMant, writer);
            // At most 10 chars written by this call, at most 11 total at this point.

            writer += strlen(writer);  // point to EOS
        }

        if (exp < 32)  // if there is a fractional part
        {
            writer = toDecimalFractionalPart(writer, num->mant, exp);
            // At most DEC_ACC_WIDTH + 6 chars written by this call,
            // at most DEC_ACC_WIDTH + 17 total at this point.
        }
    }
    else  // there is no fractional part, and integer part too large for 32 bits
    {
        writer = toDecimalLargeIntegerNoFraction(writer, exp, ulongMant);
        // At most DEC_ACC_WIDTH + 5 chars written by this call,
        // at most DEC_ACC_WIDTH + 6 total at this point.
    }

    *writer = '\0';
    roundDecimalString(dest, 9);

    // At most DEC_ACC_WIDTH + 18 at this point.
}
