#include "floatable-private.h"


static const UFloat40 ten = { BIAS + 4, { 0xA0, 0x00, 0x00, 0x00 }, 0x00 };
static const UFloat40 oneTenth = { BIAS - 3, { 0xCC, 0xCC, 0xCC, 0xCD }, 0x00 };
static const UFloat40 hugeVal = { BIAS + 127, { 0xFF, 0xFF, 0xFF, 0xFF }, 0x00 };


static byte
returnOverflow(UFloat40 *dest, BOOL isNegative)
{
    *dest = hugeVal;
    if (isNegative)
    {
        dest->sign = 0xFF;
        return 2;
    }
    return 1;
}


byte
floatable_fromDecimal(UFloat40 *dest, const char *decimal, char **endptr)
{
    // Process the number's sign, if anyway.
    //
    BOOL isNegative = (*decimal == '-');
    const char *postSign = decimal;
    if (isNegative || *decimal == '+')
        ++postSign;

    floatable_setUFloat40ToZero(dest);

    if (*postSign != '.' && ! (BOOL) isdigit(*postSign) && (char) toupper(*postSign) != 'E')
    {
        if (endptr)
            *endptr = (char *) decimal;
        return 0;  // no conversion, presented as successful parse of 0
    }
    
    decimal = postSign;

    // Process pre-exponent digits and decimal point, if any.
    //
    BOOL decimalPointSeen = FALSE, nonZeroDigitSeenBeforeE = FALSE;
    char powerOfTen = 0;  // number will be multiplied by 10 to this power
    byte err;

    for (;;)
    {
        //printf("# floatable_fromDecimal: *decimal='%c'\n", *decimal);
        if (*decimal == '.')
        {
            ++decimal;
            decimalPointSeen = TRUE;
        }
        else if (! (BOOL) isdigit(*decimal))
            break;
        else
        {
            byte asciiDigit = *decimal++;
            if (asciiDigit != '0')
                nonZeroDigitSeenBeforeE = TRUE;
            if (decimalPointSeen)
                --powerOfTen;

            // Do *dest = *dest * 10.0 + the-new-digit.

            // TODO: Imitate CoCo routine at $BB6A and do times 4, save, times 2, add saved.

            err = fmul(dest, &ten);
            if (err != 0)
            {
                //printf("# floatable_fromDecimal/A: err=%u\n", err);
                if (endptr)
                    *endptr = (char *) decimal;
                return returnOverflow(dest, isNegative);
            }

            //printf("# floatable_fromDecimal: after mul by 10: ");
            //UFloat40_print(dest);
            //printf("\n");

            UFloat40 newDigit;
            asm
            {
_fromInt IMPORT
_fadd    IMPORT
                ldb     :asciiDigit
                subb    #'0'            ; convert to 0..9
                beq     @addDone
;
                clra                    ; D is 0..9
                leax    :newDigit
                lbsr    _fromInt        ; init newDigit with 0..9
;
                pshs    u
                ldx     :dest
                leau    :newDigit
                lbsr    _fadd           ; add newDigit to *dest
                puls    u
@addDone
            }

            //printf("# floatable_fromDecimal: after adding digit %c: ", asciiDigit);
            //UFloat40_print(dest);
            //printf("\n");
        }
    }

    // Parse an optional /E[-\+]?\d*/.
    //
    if (toupper(*decimal) == 'E')
    {
        ++decimal;
        BOOL isExpNegative = (*decimal == '-');
        if (isExpNegative || *decimal == '+')
            ++decimal;
        char expDigits[2];  // overflow if > 99
        expDigits[0] = 0;  // to support case where no digits after E
        byte numDigits = 0;
        for ( ; (BOOL) isdigit(*decimal); ++decimal)
        {
            if (numDigits == 2)
            {
                if (endptr)
                    *endptr = (char *) decimal;
                //printf("# floatable_fromDecimal/D: err=%u\n", err);
                return returnOverflow(dest, isNegative);
            }
            expDigits[numDigits++] = *decimal - '0';
        }
        char exp = (numDigits == 2 ? expDigits[0] * 10 + expDigits[1] : expDigits[0]);
        if (isExpNegative)
            exp = -exp;
        // Add exp to powerOfTen, but avoid overflow,
        // i.e., exp + powerOfTen > 127 || exp + powerOfTen < -128,
        int sum = (int) powerOfTen + (int) exp;
        //printf("# floatable_fromDecimal/D: %d + %d = %d\n", powerOfTen, exp, sum);
        if (sum < -128 || sum > 127)
        {
            if (endptr)
                *endptr = (char *) decimal;
            return returnOverflow(dest, isNegative);
        }
        powerOfTen = (char) sum;
    }
    

    //printf("# floatable_fromDecimal: nonZeroDigitSeenBeforeE=%d, powerOfTen=%d\n", nonZeroDigitSeenBeforeE, powerOfTen);
    if (!nonZeroDigitSeenBeforeE)
    {
        //printf("# floatable_fromDecimal: !nonZeroDigitSeenBeforeE: ");
        //UFloat40_print(dest);
        //printf("\n");
        if (endptr)
            *endptr = (char *) decimal;
        return 0;
    }

    // TODO: Use tables to reduce the looping in the following multiplications.

    for ( ; powerOfTen < 0 ; ++powerOfTen)
    {
        err = fmul(dest, &oneTenth);
        if (err != 0)
        {
            //printf("# floatable_fromDecimal/B: err=%u\n", err);
            if (endptr)
                *endptr = (char *) decimal;
            return returnOverflow(dest, isNegative);
        }
    }
    for ( ; powerOfTen > 0 ; --powerOfTen)
    {
        //printf("# floatable_fromDecimal/C: powerOfTen=%d, dest=", powerOfTen);
        //UFloat40_print(dest); printf("\n");
        err = fmul(dest, &ten);
        //printf("# floatable_fromDecimal/C:   err=%u, dest=", err);
        //UFloat40_print(dest); printf("\n");
        if (err != 0)
        {
            //printf("# floatable_fromDecimal/C:   overflow\n");
            if (endptr)
                *endptr = (char *) decimal;
            return returnOverflow(dest, isNegative);
        }
    }

    if (isNegative)
        dest->sign = 0xFF;

    if (endptr)
        *endptr = (char *) decimal;
    return 0;
}
