#include "floatable-private.h"


// N.B.: This function performs a substraction. A faster comparison
//       should be feasible with custom code.
// TODO: Use optims done by $BC96.
//
char
floatable_cmpUFloat40(const UFloat40 *left, const UFloat40 *right)
{
    UFloat40 leftCopy = *left, rightCopy = *right;
    // Store *left minus *right in 'leftCopy':
    asm
    {
_fsub           IMPORT
        pshs    u
        leax    :leftCopy
        leau    :rightCopy
        lbsr    _fsub           ; trashes rightCopy
        puls    u
    }
    // printf("# floatable_cmpUFloat40: after _fsub:\n# ");
    // UFloat40_print(&leftCopy);
    // printf("\n");
    if (isZero(&leftCopy))
        return 0;  // equal
    return leftCopy.sign ? -1 : +1;
}
