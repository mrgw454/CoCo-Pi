#include "floatable-private.h"


// left -= right.
//
asm __norts__ void
subtract32From40(byte left[5], const byte right[4])
{
    asm
    {
        pshs    u
        ldx     4,s             ; left
        ldu     6,s             ; right
        ldd     3,x             ; left[3..4]
        subd    2,u             ; right[2..3]
        std     3,x
        ldd     1,x             ; left[1..2]
        sbcb    1,u             ; right[1]
        sbca    ,u              ; right[0]
        std     1,x
        ldb     ,x              ; left[0]
        sbcb    #0              ; right[-1]
        stb     ,x
        puls    u,pc
    }
}
