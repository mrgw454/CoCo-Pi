#include "floatable-private.h"


// Adds src[0..4] to dest[1..5], then increments dest[0] if there is a carry.
//
void
add40bitsWithCarry(byte dest[6], const byte src[5])
{
    asm
    {
        pshs    y
        ldx     :dest
        ldy     :src

        ldd     3,y         ; load src[3..4]
        addd    4,x         ; add to dest[4..5], set C if carry
        std     4,x
        
        ldd     1,y         ; load src[1..2]
        adcb    3,x         ; add carry from previous add, plus dest[2..3]
        adca    2,x         ; set C if carry
        std     2,x
        
        ldb     ,y          ; load src[0]
        adcb    1,x         ; add carry from previous add, plus dest[1], set C if carry
        stb     1,x
        
        bcc     @noCarry
        inc     ,x
@noCarry
        puls    y
    }
}


void
mul8by32(byte dest[5], byte k, const byte r[4])
{
    /*
        k * (R0,R1,R2,R3)
        =   k * R3 * 2^0        product word goes in dest[3..4]
          + k * R2 * 2^8        product word goes in dest[2..3]
          + k * R1 * 2^16       product word goes in dest[1..2]
          + k * R0 * 2^24       product word goes in dest[0..1]
    */
    asm
    {
        pshs    y
        ldx     :dest
        ldy     :r

        lda     :k
        ldb     3,y
        mul
        std     3,x
        
        lda     :k
        ldb     2,y
        mul
        addb    3,x
        adca    #0
        std     2,x
        
        lda     :k
        ldb     1,y
        mul
        addb    2,x
        adca    #0
        std     1,x
        
        lda     :k
        ldb     ,y
        mul
        addb    1,x
        adca    #0
        std     ,x
        
        puls    y
    }
}


// 64-bit result left in dest[1..8]. dest[0] left undefined.
//
void 
mul32to64(byte dest[9], const byte left[4], const byte right[4])
{
    /*
        Let L0,L1,L2,L3 be the 4 bytes of the left operand.
        Let R0,R1,R2,R3 be the 4 bytes of the right operand.
        The product is
                 L3 * (R0,R1,R2,R3)
        + 2^8  * L2 * (R0,R1,R2,R3)
        + 2^16 * L1 * (R0,R1,R2,R3)
        + 2^24 * L0 * (R0,R1,R2,R3)

        Let A0..A4 by the 40-bit product of L3 and R*.
        Let B0..B4 by the 40-bit product of L2 and R*.
        Similarly for C* and D*. The final product is this:

        +             A0 A1 A2 A3 A4 
        +          B0 B1 B2 B3 B4 
        +       C0 C1 C2 C3 C4 
        +    D0 D1 D2 D3 D4 
          0  1  2  3  4  5  6  7  8   <- Indices in dest[9]
          
        dest[0] will remain 0 because the maximum product is
        0xfffffffe00000001, which fits in dest[1..8] bytes.
    */
    
    * (unsigned long *) dest = 0;  // init first 4 bytes
    mul8by32(dest + 4, left[3], right);  // writes 5-byte product to dest[4..8]

    byte temp[5];

    mul8by32(temp, left[2], right);     // compute B0..B4
    add40bitsWithCarry(dest + 2, temp); // add B0..B4 to dest[2..7]

    mul8by32(temp, left[1], right);     // compute C0..C4
    add40bitsWithCarry(dest + 1, temp); // add C0..C4 to dest[1..6]
    
    mul8by32(temp, left[0], right);     // compute D0..D4
    add40bitsWithCarry(dest, temp);     // add D0..D4 to dest[0..5]
}


// *fp0 = *fp0 * *fp1.
// Returns 0 upon success, or an error code upon failure (overflow).
//
byte
fmul(UFloat40 *fp0, const UFloat40 *fp1)
{
    //printf("# fmul: fp0: "); UFloat40_print(fp0); printf("\n");
    //printf("# fmul: fp1: "); UFloat40_print(fp1); printf("\n");
    if (fp0->biasedExp == 0 || fp1->biasedExp == 0)
    {
        memset(fp0, 0, sizeof(*fp0));
        return 0;
    }
    char e0 = fp0->biasedExp - BIAS, e1 = fp1->biasedExp - BIAS;
    int expSum = (int) e0 + (int) e1;  // may go beyond -128..127
    char prodSign = (!!fp0->sign == !!fp1->sign ? 0 : 0xFF);
    byte mantProd[9];  // [1..8] receives 64-bit product
    mul32to64(mantProd, (byte *) fp0->mant, (const byte *) fp1->mant);
    * (unsigned long *) fp0->mant = * (unsigned long *) (mantProd + 1);
    if ((mantProd[1] & 0x80) == 0)  // if left shift required
    {
        //printf("# fmul: left shift\n");
        * (unsigned long *) fp0->mant <<= 1;
        if (--expSum == 0)
            return 2;  // overflow
    }
    
    if (expSum < -127 || expSum > 127)
        return 1;  // overflow

    //printf("# fmul: final non-biased exp: %d\n", expSum);
    fp0->biasedExp = BIAS + (byte) expSum;
    fp0->sign = prodSign;
    return 0;
}


void
floatable_mulUFloat40(UFloat40 *fp0, const UFloat40 *fp1)
{
    (void) fmul(fp0, fp1);
}
