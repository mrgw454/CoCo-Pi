#ifndef _H_floatable_private
#define _H_floatable_private


#include "floatable.h"


#define isZero(ufloat40Ptr) ((ufloat40Ptr)->biasedExp == 0)


enum
{
    BIAS = 128,
    DEC_ACC_WIDTH = 10,  // number of digits in the decimal accumulator; affects interface of floatable_toDecimal()
};

#define copyMantissa(dest, src) (memcpy((dest), (src), 4))

void floatable_setUFloat40ToZero(UFloat40 *dest);

BOOL halveDecAcc(char decAcc[DEC_ACC_WIDTH]);

void roundDecimalString(char dest[], byte numSignificantDigits);

void addToDecAcc(char decAcc[DEC_ACC_WIDTH + 1], const char digits[DEC_ACC_WIDTH + 1], char powerOf10);

void mul8by32(byte dest[5], byte k, const byte r[4]);

void mul32to64(byte dest[9], const byte left[4], const byte right[4]);

void add40bitsWithCarry(byte dest[6], const byte src[5]);

// *fp0 = *fp0 * *fp1.
// Returns 0 upon success, or an error code upon failure (overflow).
//
byte fmul(UFloat40 *fp0, const UFloat40 *fp1);

void div_32_32_to_40(byte quotient[5], byte dividend[4], const byte divisor[4]);

// dividend, divisor: Must not be 0.0.
// dividend, divisor and divisor must be distinct arrays.
//
void div40by32(byte quotient[5], byte *numShiftsBeforeFirstSetBit,
               byte dividend[5], const byte divisor[5]);

void subtract32From40(byte left[5], const byte right[4]);

char compareAccWithDivisor(const byte acc[5], const byte divisor[4]);

byte shift5BytesLeft1Bit(byte v[5], byte bitToShiftIn);

void UFloat40_print(const UFloat40 *f);


// Assert system.
//

#ifndef NDEBUG


#define assert(condition) (_assert(condition, #condition, __FILE__, __LINE__))


BOOL _assert(BOOL evaluatedCondition, const char *conditionExpr, const char *fn, int line);


// Asserts that b is a boolean value, i.e., 0 or 1.
//
#define assert_bool_value(b) (assert((b) == 0 || (b) == 1))


#define assert_eq(actual, expected) \
    do { if ((actual) != (expected)) { \
        printf("ERROR at line %s:%d: assert_eq(" #actual ", " #expected ") failed\n", __FILE__, __LINE__); \
        exit(1); \
    } } while (FALSE)

#define assert_ne(actual, expected) \
    do { if ((actual) == (expected)) { \
        printf("ERROR at line %s:%d: assert_ne(" #actual ", " #expected ") failed\n", __FILE__, __LINE__); \
        exit(1); \
    } } while (FALSE)


#define assert_eq_str(actual, expected) (_assert_eq_str(actual, expected, __FILE__, __LINE__))


BOOL _assert_eq_str(const char *actual, const char *expected, const char *fn, int line);


#else  /* defined(NDEBUG) */

#define assert(condition) ((void) 0)

#define _assert(evaluatedCondition, conditionExpr, fn, line) (0)

#define assert_bool_value(b) ((void) 0)

#define assert_eq(actual, expected) ((void) 0)

#define assert_ne(actual, expected) ((void) 0)

#define assert_eq_str(actual, expected) ((void) 0)

#define _assert_eq_str(actual, expected, fn, line) (0)


#endif  /* ndef NDEBUG */


#endif  /* _H_floatable_private */
