#ifndef _H_floatable
#define _H_floatable

#include <coco.h>


// Packed 40-bit floating point accumulator.
//
typedef struct PFloat40
{
    byte biasedExp;  // exponent with BIAS added to it (e.g., 131 = 128 + 3 = exponent is 3);
                     // zero means number is 0.0
    byte mant[4];    // big endian, high bit is sign (1 = negative)
} PFloat40;


// Unpacked version of PFloat40.
//
typedef struct UFloat40
{
    byte biasedExp;  // exponent with BIAS added to it (e.g., 131 = 128 + 3 = exponent is 3);
                     // zero means number is 0.0
    byte mant[4];    // big endian
    byte sign;       // 0 = positive, otherwise negative
} UFloat40;


void floatable_unpack(UFloat40 *dest, const PFloat40 *src);

void floatable_pack(PFloat40 *dest, const UFloat40 *src);


// Converts the given number to an ASCII decimal, NUL-terminated representation in 'dest'.
//
void floatable_toDecimal(char dest[28], const UFloat40 *num);


// dest: Receives the parsed value. If no character is used, receives zero.
// decimal: NUL-terminated ASCII string to parse.
//          Expected to match this regex: [-\+]?\d*\.\d*[Ee][-\+]?\d+
// endptr: If not NULL, a pointer to the character after the last character used
//         in the conversion is stored in the location referenced by endptr.
// Returns 0 upon success;
//         1 upon a positive overflow (*dest becomes highest positive number).
//         2 upon a negative overflow (*dest becomes lowest negative number).
//
byte floatable_fromDecimal(UFloat40 *dest, const char *decimal, char **endptr);


// Adds *fp1 to *fp0.
//
void floatable_addUFloat40(UFloat40 *fp0, const UFloat40 *fp1);


// Subtracts *fp1 from *fp0.
//
void floatable_subUFloat40(UFloat40 *fp0, const UFloat40 *fp1);


void floatable_mulUFloat40(UFloat40 *fp0, const UFloat40 *fp1);


// Quotient is left in *dividend.
// Returns 0 on success, 1 on division by zero, 2 on overflow.
// On a division by zero, *dividend receives the largest value
// of the sign of the dividend.
//
BOOL floatable_divUFloat40(UFloat40 *dividend, const UFloat40 *divisor);


// Compares *left to *right.
// Returns  0 if the two numbers are equal,
//         -1 if *left is lower than *right,
//         +1 if *left is greater than *right.
//
char floatable_cmpUFloat40(const UFloat40 *left, const UFloat40 *right);


void floatable_setUFloat40ToSignedInt(UFloat40 *dest, signed int n);


void floatable_normalizeUFloat40(UFloat40 *fp, BOOL negateFirst);


#endif  /* _H_floatable */
