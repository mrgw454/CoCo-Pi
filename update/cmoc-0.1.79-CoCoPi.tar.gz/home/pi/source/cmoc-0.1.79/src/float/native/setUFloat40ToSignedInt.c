#include "floatable-private.h"


asm void
floatable_setUFloat40ToSignedInt(UFloat40 *dest, signed int n)
{
    asm
    {
_fromInt IMPORT
        ldx     2,s         ; dest
        ldd     4,s         ; n
        lbra    _fromInt
    }
}
