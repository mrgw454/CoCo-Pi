#include "floatable-private.h"


static void
negateSignAndMatissa(UFloat40 *fp)
{
    fp->sign = ~ fp->sign;
    * (long *) fp->mant = - * (long *) fp->mant;
}


void
floatable_normalizeUFloat40(UFloat40 *fp, BOOL negateFirst)
{
    if (negateFirst)
        negateSignAndMatissa(fp);

    byte numBitShifts = 0;

    // Shift left by bytes until high byte not zero.
    //
    while (fp->mant[0] == 0)
    {
        asm
        {
shift4BytesAtXLeft1Byte IMPORT
            ldx     :fp
            leax    1,x     ; point to mant field
            lbsr    shift4BytesAtXLeft1Byte
        }
        numBitShifts += 8;
        if (numBitShifts >= 40)
        {
            floatable_setUFloat40ToSignedInt(fp, 0);
            return;
        }
    }
    
    // Shift left by bits until high bit is 1.
    //
    while ((fp->mant[0] & 0x80) == 0)
    {
        //shiftBitsLeft(fp->mant);
        asm
        {
shift4BytesAtXLeft1Bit IMPORT
            ldx     :fp
            leax    1,x     ; point to mant field
            lbsr    shift4BytesAtXLeft1Bit
            
            inc     :numBitShifts
        }
    }
    
    // Subtract numBitShifts from biased exponent. If result not positive, set FP to 0.
    //
    byte *biasedExp = &fp->biasedExp;
    asm
    {
        lda     [:biasedExp]
        suba    :numBitShifts
        sta     [:biasedExp]
        bhi     @done
        ldx     #0
        ldd     :fp
        pshs    x,d
        lbsr    _floatable_setUFloat40ToSignedInt
        leas    4,s
@done
    }
}
