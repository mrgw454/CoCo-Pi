#include "floatable-private.h"


void
UFloat40_print(const UFloat40 *f)
{
    if (!f->biasedExp)
        printf("ZERO (%02X, 0x%02X%02X%02X%02X)",
                f->sign,
                f->mant[0], f->mant[1], f->mant[2], f->mant[3]);
    else
        printf("%c0x%02X%02X%02X%02X*2**%d",
                f->sign ? '-' : '+',
                f->mant[0], f->mant[1], f->mant[2], f->mant[3],
                (char) f->biasedExp - BIAS);
}
