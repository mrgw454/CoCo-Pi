#include "floatable-private.h"


asm void
floatable_setUFloat40ToZero(UFloat40 *dest)
{
    asm
    {
        ldx     2,s         ; dest
        clr     ,x
        clr     1,x
        clr     2,x
        clr     3,x
        clr     4,x
        clr     5,x
    }
}
