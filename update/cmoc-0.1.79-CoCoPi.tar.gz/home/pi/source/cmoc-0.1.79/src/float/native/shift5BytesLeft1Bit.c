#include "floatable-private.h"


// Returns the bit that gets shifted out.
//
asm byte
shift5BytesLeft1Bit(byte v[5], byte bitToShiftIn)
{
    asm
    {
        ldx     2,s     ; v
        lsr     5,s     ; put bitToShiftIn in C
        rol     4,x     ; shift C into 4,x
        rol     3,x
        rol     2,x
        rol     1,x
        rol     ,x
        tfr     cc,b
        andb    #1
    }
}
