<?php

    $address = 0xc000 + (($line / 8) * 80) + (($line % 8) * 2048)

