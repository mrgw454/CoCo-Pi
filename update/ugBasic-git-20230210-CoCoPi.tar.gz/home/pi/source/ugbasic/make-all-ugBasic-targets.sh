#!/bin/bash

make target=coco clean
make target=atarixl clean
make target=c128 clean
make target=c64 clean
make target=coleco clean
make target=msx1 clean
make target=d32 clean
make target=d64 clean
make target=zx clean

make target=coco compiler
make target=atarixl compiler
make target=c128 compiler
make target=c64 compiler
make target=coleco compiler
make target=msx1 compiler
make target=d32 compiler
make target=d64 compiler
make target=zx compiler
