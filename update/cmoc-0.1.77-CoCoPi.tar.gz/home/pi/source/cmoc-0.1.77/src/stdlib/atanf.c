void _CMOC_applyRealFunction(void *fpa0Transform, float *p);


float
atanf(float tangent)
{
    _CMOC_applyRealFunction((void *) 0x83B0, &tangent);
    return tangent;  // angle in radians
}
