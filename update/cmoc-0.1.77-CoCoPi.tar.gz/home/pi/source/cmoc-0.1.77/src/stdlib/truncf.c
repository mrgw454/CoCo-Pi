void _CMOC_applyRealFunction(void *fpa0Transform, float *p);


float
truncf(float x)
{
    _CMOC_applyRealFunction((void *) 0x8524, &x);  // call Basic's FIX function
    return x;
}
