void _CMOC_applyRealFunction(void *fpa0Transform, float *p);


float
sinf(float radians)
{
    _CMOC_applyRealFunction((void *) 0xBF78, &radians);
    return radians;
}
