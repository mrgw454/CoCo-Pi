void _CMOC_applyRealFunction(void *fpa0Transform, float *p);


float
cosf(float radians)
{
    _CMOC_applyRealFunction((void *) 0x8378, &radians);
    return radians;
}
