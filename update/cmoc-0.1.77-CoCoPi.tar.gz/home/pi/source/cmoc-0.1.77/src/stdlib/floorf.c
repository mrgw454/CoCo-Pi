void _CMOC_applyRealFunction(void *fpa0Transform, float *p);


float
floorf(float x)
{
    _CMOC_applyRealFunction((void *) 0xBCEE, &x);  // call Basic's INT function
    return x;
}
