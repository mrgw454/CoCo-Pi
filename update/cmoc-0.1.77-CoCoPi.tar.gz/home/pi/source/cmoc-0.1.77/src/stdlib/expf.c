void _CMOC_applyRealFunction(void *fpa0Transform, float *p);


float
expf(float x)
{
    _CMOC_applyRealFunction((void *) 0x84F2, &x);
    return x;
}
