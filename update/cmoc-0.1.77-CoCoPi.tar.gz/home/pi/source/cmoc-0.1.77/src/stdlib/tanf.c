void _CMOC_applyRealFunction(void *fpa0Transform, float *p);


float
tanf(float radians)
{
    _CMOC_applyRealFunction((void *) 0x8381, &radians);
    return radians;
}
