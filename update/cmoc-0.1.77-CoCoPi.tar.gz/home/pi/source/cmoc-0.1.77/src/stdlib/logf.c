void _CMOC_applyRealFunction(void *fpa0Transform, float *p);


float
logf(float x)
{
    _CMOC_applyRealFunction((void *) 0x8446, &x);
    return x;
}
