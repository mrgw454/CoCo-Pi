/*

cas2wav - convert Dragon/Tandy CoCo CAS file to WAV
Copyright 2013-2021 Ciaran Anscomb
License CC BY 4.0: https://creativecommons.org/licenses/by/4.0/

v0.6: support different sample rates, 8- or 16-bit sample sizes, 1 or 2
      channels, sine or approximated square wave.
v0.7: CUE support
v0.8: help text tweaks

C99 required - you might need -std=c99 when compiling with gcc.
Maths functions used: link with -lm.

For plain CAS files, the default sample rate is 9600Hz.  If CUE data is found,
the default is raised to 22050Hz.  For sample rates less than 11025Hz, cycle
frequencies are exactly 1200Hz and 2400Hz, else a closer approximation to what
the Dragon ROM writes is chosen.  CUE data may override these default cycle
widths, hence the higher default sample rate.

Set sample rate with -r, sample size with -b, channel count with -c.  The
defaults optimise for size, but if you're going to be recording to a real
cassette tape, increasing is a good idea, e.g.: -r 48000 -b 16

Pure sine waves are the default, so -s is a no-op.

-q doesn't generate pure square wave data, but instead adds harmonics to the
fundamental up to nyquist (sample rate / 2).  This seems to make it more
resilient during subsequent sample rate conversions.

The harmonic limit can be modified with -t.  Simulate your naff old tapes
with -t 12000!  Just need a noise option now...

*/

#define _POSIX_C_SOURCE 200112L

#ifndef PACKAGE_VERSION
#define PACKAGE_VERSION "0.8"
#endif

#ifndef PACKAGE_NAME
#define PACKAGE_NAME "cas2wav"
#endif

#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* CUE chunk types */

#define CUE_TIMING (0xf0)
#define CUE_SILENCE (0x00)
#define CUE_DATA (0x0d)

/* Bits of this will be filled in before writing. */

static uint8_t wav_header[44] = {
	'R', 'I', 'F', 'F', 0x00, 0x00, 0x00, 0x00,
	'W', 'A', 'V', 'E', 'f', 'm', 't', ' ',
	0x10, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x01, 0x00, 0x08, 0x00, 'd', 'a', 't', 'a',
	0x00, 0x00, 0x00, 0x00
};

static int sample_rate = 0;
static int tape_rate = 0;
static int bits_per_sample = 8;
static int num_channels = 1;
static int bytes_per_sample;
static _Bool square_wave = 0;

static void usagetext(FILE *f, const char *argv0);
static void helptext(const char *argv0);
static void versiontext(void);

static int read_uint16(FILE *fd);
static int read_vl_uint31(FILE *fd);

static off_t write_wave(FILE *out, int freq);
static off_t write_chunk(FILE *in, FILE *out, off_t from, off_t to, int bit0_freq, int bit1_freq);

int main(int argc, char **argv) {
	FILE *in, *out;
	_Bool check_cue = 1;

	int opt;
	while ((opt = getopt(argc, argv, "r:t:b:c:sqfVh")) != -1) {
		switch (opt) {
		case 'r':
			sample_rate = atoi(optarg);
			break;
		case 't':
			tape_rate = atoi(optarg);
			break;
		case 'b':
			bits_per_sample = atoi(optarg);
			break;
		case 'c':
			num_channels = atoi(optarg);
			break;
		case 's':
			square_wave = 0;
			break;
		case 'q':
			square_wave = 1;
			break;
		case 'f':
			check_cue = 0;
			break;
		case 'V':
			versiontext();
			exit(EXIT_SUCCESS);
		case 'h':
			helptext(argv[0]);
			exit(EXIT_SUCCESS);
		default:
			exit(EXIT_FAILURE);
		}
	}

	if ((optind + 1) >= argc) {
		usagetext(stderr, argv[0]);
		fprintf(stderr, "Try '%s -h' for more information.\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	// Have to open input file early in order to detect whether CUE data
	// exists, as this guides the default value for sample_rate.

	if ((in = fopen(argv[optind], "rb")) == NULL) {
		perror("Failed to open input file");
		exit(EXIT_FAILURE);
	}

	// CUE data?
	_Bool cue_data = 0;
	off_t cue_start = -1;
	off_t cue_end = -1;
	while (check_cue) {  // dummy loop construct
		// file must end "CUE]"
		if (fseeko(in, -4, SEEK_END) == -1)
			break;
		if (read_uint16(in) != 0x4355 || read_uint16(in) != 0x455d)
			break;
		// found - start ptr found at EOF-8
		if (fseeko(in, -8, SEEK_END) == -1)
			break;
		if ((cue_end = ftello(in)) == -1)
			break;
		cue_start = (read_uint16(in) << 16) | read_uint16(in);
		if (fseeko(in, cue_start, SEEK_SET) == -1)
			break;
		// must start "[CUE"
		if (read_uint16(in) != 0x5b43 || read_uint16(in) != 0x5545)
			break;
		cue_data = 1;
		break;
	}

	if (sample_rate <= 0) {
		sample_rate = cue_data ? 22050 : 9600;
	}

	if ((sample_rate < 4800 || sample_rate > 192000)) {
		fprintf(stderr, "unsupported sample rate: use 4800-192000\n");
		exit(EXIT_FAILURE);
	}

	if (bits_per_sample != 8 && bits_per_sample != 16) {
		fprintf(stderr, "unsupported bits per sample: use 8 or 16\n");
		exit(EXIT_FAILURE);
	}

	if (num_channels < 1 || num_channels > 2) {
		fprintf(stderr, "unsupported number of channels: use 1 or 2\n");
		exit(EXIT_FAILURE);
	}

	if (tape_rate == 0)
		tape_rate = sample_rate / 2;

	if (tape_rate < 2400 || tape_rate > 96000) {
		fprintf(stderr, "unsupported tape rate: use 2400-96000\n");
		exit(EXIT_FAILURE);
	}

	bytes_per_sample = bits_per_sample >> 3;

	if ((out = fopen(argv[optind+1], "wb")) == NULL) {
		perror("Failed to open output file");
		exit(EXIT_FAILURE);
	}

	// default frequencies approximately optimal for reading by ROM
	int bit0_freq = 1118;
	int bit1_freq = 2052;

	// low sample rates can't represent that well enough though
	if (sample_rate < 11025) {
		bit0_freq = 1200;
		bit1_freq = 2400;
	}

	// NumChannels
	wav_header[22] = num_channels;
	wav_header[23] = 0;
	// SampleRate
	wav_header[24] = sample_rate & 0xff;
	wav_header[25] = (sample_rate >> 8) & 0xff;
	wav_header[26] = (sample_rate >> 16) & 0xff;
	wav_header[27] = (sample_rate >> 24) & 0xff;
	// ByteRate
	unsigned byte_rate = sample_rate * num_channels * bytes_per_sample;
	wav_header[28] = byte_rate & 0xff;
	wav_header[29] = (byte_rate >> 8) & 0xff;
	wav_header[30] = (byte_rate >> 16) & 0xff;
	wav_header[31] = (byte_rate >> 24) & 0xff;
	// BlockAlign
	unsigned block_align = (num_channels * bits_per_sample) / 8;
	wav_header[32] = block_align & 0xff;
	wav_header[33] = (block_align >> 8) & 0xff;
	// BitsPerSample
	wav_header[34] = bits_per_sample;
	wav_header[35] = 0;

	if (fwrite(wav_header, 1, sizeof(wav_header), out) < 44) {
		perror("Failed to write WAV header");
		exit(EXIT_FAILURE);
	}

	// Running total of how many samples have been written.  WAV header
	// will be updated at end of writing using this value.
	unsigned count = 0;

	if (!cue_data) {
		// no CUE data: simple dump from beginning until EOF
		count += write_chunk(in, out, 0, -1, bit0_freq, bit1_freq);
	} else {
		// iterate over CUE entries
		for (;;) {
			off_t pos = ftello(in);
			if (pos == -1) {
				perror(NULL);
				exit(EXIT_FAILURE);
			}
			if (pos >= cue_end)
				break;
			int type = fgetc(in);
			if (type < 0) {
				perror("Failure reading CUE type");
				exit(EXIT_FAILURE);
			}
			int size = read_vl_uint31(in);
			if (size < 0) {
				perror("Failure reading CUE size");
				exit(EXIT_FAILURE);
			}
			switch (type) {
			case CUE_TIMING:
				if (size != 4) {
					fprintf(stderr, "CUE_TIMING: bad size\n");
					exit(EXIT_FAILURE);
				}
				bit0_freq = read_uint16(in);
				bit1_freq = read_uint16(in);
				break;
			case CUE_SILENCE:
				if (size != 2) {
					fprintf(stderr, "CUE_SILENCE: bad size\n");
					exit(EXIT_FAILURE);
				}
				{
					int ms = read_uint16(in);
					int nsamples = (sample_rate * ms) / 1000;
					for (int i = 0; i < nsamples; i++) {
						for (int j = 0; j < num_channels; j++) {
							if (bits_per_sample == 16) {
								fputc(0x00, out);
								fputc(0x00, out);
								count += 2;
							} else {
								fputc(0x80, out);
								count++;
							}
						}
					}
				}
				break;
			case CUE_DATA:
				if (size != 8) {
					fprintf(stderr, "CUE_DATA: bad size\n");
					exit(EXIT_FAILURE);
				}
				{
					off_t from = (read_uint16(in) << 16) | read_uint16(in);
					off_t to = (read_uint16(in) << 16) | read_uint16(in);
					if (to < from || to > cue_start || from > cue_start) {
						fprintf(stderr, "CUE_DATA: bad offsets\n");
						exit(EXIT_FAILURE);
					}
					count += write_chunk(in, out, from, to, bit0_freq, bit1_freq);
				}
				break;
			}
		}
	}

	// rewrite Subchunk2Size
	fseek(out, 40L, SEEK_SET);
	fputc(count & 0xff, out);
	fputc((count >> 8) & 0xff, out);
	fputc((count >> 16) & 0xff, out);
	fputc((count >> 24) & 0xff, out);
	// rewrite ChunkSize
	count += 36;
	fseek(out, 4L, SEEK_SET);
	fputc(count & 0xff, out);
	fputc((count >> 8) & 0xff, out);
	fputc((count >> 16) & 0xff, out);
	fputc((count >> 24) & 0xff, out);

	fclose(out);
	fclose(in);
	return EXIT_SUCCESS;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// Help text

static void usagetext(FILE *f, const char *argv0) {
	fprintf(f, "Usage: %s [OPTION]... INFILE OUTFILE\n", argv0);
}

static void helptext(const char *argv0) {
	usagetext(stdout, argv0);
	puts(
"Convert a Dragon/Tandy CoCo CAS file to WAV.\n\n"
"   -r RATE       set sample rate of OUTFILE (4800 - 192000) [9600]\n"
"   -t RATE       max harmonic of RATE in square wave [samplerate/2]\n"
"   -b BITS       bits per sample, 8 or 16 [8]\n"
"   -c CHANNELS   number of channels, 1 or 2 [1]\n"
"   -s            generate sine wave [default]\n"
"   -q            generate square wave\n"
"   -f            don't check for CUE data\n"
"\n"
"Note: Default sample rate will be increased to 22050Hz if CUE data is\n"
"detected in the source CAS file."
	);
}

static void versiontext(void) {
	puts(
PACKAGE_NAME " " PACKAGE_VERSION "\n"
"Copyright 2013-2021 Ciaran Anscomb\n"
"License CC BY 4.0: https://creativecommons.org/licenses/by/4.0/"
	);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// Read 16-bit unsigned value

static int read_uint16(FILE *fd) {
	int v0 = fgetc(fd);
	if (v0 < 0)
		return -1;
	int v1 = fgetc(fd);
	if (v1 < 0)
		return -1;
	return (v0 << 8) | v1;
}

// Read a variable-length max 31-bit unsigned int

static int read_vl_uint31(FILE *fd) {
	int val0 = fgetc(fd);
	if (val0 < 0)
		return -1;
	int tmp = val0;
	int shift = 0;
	int mask = 0xff;
	int val1 = 0;
	while ((tmp & 0x80) == 0x80) {
		tmp <<= 1;
		shift += 8;
		mask >>= 1;
		int in = fgetc(fd);
		if (in < 0)
			return -1;
		if (shift > 24) {
			in &= 0x7f;
			mask = 0;  // ignore val0
			tmp = 0;  // no more
		}
		val1 = (val1 << 8) | in;
	}
	return ((val0 & mask) << shift) | val1;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// Write a single wave of the desired frequency

static off_t write_wave(FILE *out, int freq) {
	off_t count = 0;
	int ao_index = freq >> 1;

	do {
		double a = (double)ao_index / (double)sample_rate;
		double v = sin(a * 2.0 * M_PI);

		if (square_wave) {
			// add harmonics up to the "tape rate"
			int k = 3;
			int r = freq * k;
			while (r <= tape_rate) {
				double h = a * (double)k;
				v += sin(h * 2.0 * M_PI) / (double)k;
				k += 2;
				r = freq * k;
			}
		}
		v *= 0.7855;

		if (bits_per_sample == 16) {
			uint16_t dv = v * 32767.;
			fputc(dv & 0xff, out);
			fputc((dv >> 8) & 0xff, out);
			count += 2;
		} else {
			uint8_t dv = (v * 127.) + 128.;
			fputc(dv, out);
			count++;
		}
		ao_index += freq;
	} while (ao_index < sample_rate);

	return count;
}

// Convert chunk of data from input to output at desired frequencies
// Call with to = -1 to read to EOF
// Returns number of samples written

static off_t write_chunk(FILE *in, FILE *out, off_t from, off_t to, int bit0_freq, int bit1_freq) {
	int freq[2] = { bit0_freq, bit1_freq };
	off_t old_position = ftello(in);
	fseeko(in, from, SEEK_SET);
	off_t count = 0;
	while (to == -1 || from < to) {
		int c = fgetc(in);
		if (c == EOF)
			break;
		from++;
		for (int i = 0; i < 8; i++) {
			int bit = c & 1;
			count += write_wave(out, freq[bit]);
			c >>= 1;
		}
	}
	fseeko(in, old_position, SEEK_SET);
	return count;
}
