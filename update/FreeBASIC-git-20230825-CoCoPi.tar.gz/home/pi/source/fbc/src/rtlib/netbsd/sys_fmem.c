/* fre() function */

#include "../fb.h"

FBCALL size_t fb_GetMemAvail( int mode )
{
	/* !!!WRITEME!!! */
	return 0;
}
