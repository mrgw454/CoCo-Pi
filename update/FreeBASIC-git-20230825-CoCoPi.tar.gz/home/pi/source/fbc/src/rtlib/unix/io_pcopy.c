/* console pcopy function */

#include "../fb.h"
#include "fb_private_console.h"

int fb_ConsolePageCopy( int src, int dst )
{
	return fb_ErrorSetNum( FB_RTERROR_ILLEGALFUNCTIONCALL );
}
