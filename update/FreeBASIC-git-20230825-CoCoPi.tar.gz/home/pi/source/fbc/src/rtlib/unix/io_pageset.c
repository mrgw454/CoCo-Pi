/* console 'screen , pg, pg' function */

#include "../fb.h"
#include "fb_private_console.h"

int fb_ConsolePageSet( int active, int visible )
{
	return -1;
}
