bootstrap_version=1.05.0
bootstrap_package=FreeBASIC-$bootstrap_version-source-bootstrap
