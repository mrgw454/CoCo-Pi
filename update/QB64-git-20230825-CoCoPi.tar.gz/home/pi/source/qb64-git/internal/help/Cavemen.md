**Cavemen** lived thousands of years ago in caves or primitive shelters.

* Using simple technology, such as clubs, they acquired food and women.
* They often used short utterances called grunts and snarls.
* In 7,000 BC they came up with the word [LET](LET). Linguists believe that this word was used in sentences such as "[Let](LET) GRRRR!" or "[Let](LET) MEEE!". Since then, the word [LET](LET) has featured prominently in the design of the BASIC programming language.
* Why are you here? Did you look up [LET](LET)? Too bad! Tell your teacher to actually teach you something!

## See Also

* [LET](LET) there be light!
* [Allow me to go back](LET)