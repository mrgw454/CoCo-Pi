The **<=** condition symbol denotes that a value must be less than or equal to another value for the condition to be True. 

*Example usage:* IF x [<=](Less-Than-Or-Equal) 320 THEN PRINT "Left or center of screen"

## See Also

* [Equal](Equal)
* [Not_Equal](Not-Equal)
* [Greater_Than_Or_Equal](Greater-Than-Or-Equal)
* [Relational Operations](Relational-Operations)
