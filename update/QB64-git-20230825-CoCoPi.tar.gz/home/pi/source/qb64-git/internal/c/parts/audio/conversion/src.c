#ifndef DEPENDENCY_AUDIO_CONVERSION
//Stubs:
//(none required)
#else
// TODO: Get rid of this entire conversion directory and it's content. This is just a stub!
#endif
