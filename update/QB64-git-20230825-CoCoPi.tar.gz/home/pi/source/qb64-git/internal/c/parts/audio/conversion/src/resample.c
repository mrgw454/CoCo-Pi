// TODO: Get rid of this entire conversion directory and it's content. This is just a stub!

int resample_c_dummy_function()
{
    return 0;
}
