#ifndef DEPENDENCY_AUDIO_DECODE
//Stubs:
//(none required)
#else
// TODO: Get rid of this entire decode directory and it's content. This is just a stub!
#define DEPENDENCY_AUDIO_DECODE_OGG
#define DEPENDENCY_AUDIO_DECODE_MP3
#define DEPENDENCY_AUDIO_DECODE_WAV
#endif

