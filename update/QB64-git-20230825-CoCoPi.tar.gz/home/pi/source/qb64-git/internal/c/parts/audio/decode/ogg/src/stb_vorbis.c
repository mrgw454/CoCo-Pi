// TODO: Get rid of this entire decode directory and it's content. This is just a stub!

int stb_vorbis_c_dummy_function()
{
    return 0;
}
