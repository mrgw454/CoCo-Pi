#!/bin/sh
g++ -s -c -w -Wall ../../src/freetypeamalgam.c -o src.o

