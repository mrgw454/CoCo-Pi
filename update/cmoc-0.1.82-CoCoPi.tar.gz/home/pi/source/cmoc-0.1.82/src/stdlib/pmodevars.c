#include <coco.h>


byte _CMOC_pmodeNo = 2;
byte *_CMOC_pmodeScreenBuffer = 0x0E00;
