# Assembly Language Programming on the TRS-80 MC-10

This contains a tutorial I wrote in 2008 that uses James Tamer's "Virtual MC10" and a shareware version of the Telemark Assembler.  Alas, I never finished it (I still regret the typo on slide 20), but it was useful enough for some members of the Yahoo MC-10 newsgroup to teach themselves assembly and make functional programs with it.

The .txt files contained here can be compiled using this simpler assembler and automatically converted into an intermediate .C10 format (which can be CLOADM'ed by most TRS-80 MC-10 emulators).

