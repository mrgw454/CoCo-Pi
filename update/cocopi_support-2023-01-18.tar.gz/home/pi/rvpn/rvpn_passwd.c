/*

 manipulating passwd via command line

*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>


#include "user.h"

int main(int argc, char *argv[]) {
    int ret;
    unsigned char b[BUFMAX];

    if (argc < 2) {
	fprintf(stderr,"usage: rvpn_passwd {user}\n");
	exit(1);
    }

    ret = get_user(argv[1]);
    if (ret) {
	printf("error: user does not exist\n");
	exit(1);
    }
 again:
    fprintf(stderr,"password: ");
    ret = read(0, b, BUFMAX-1);
    if (ret <= 1) {
	fprintf(stderr,"not long enough\n");
	goto again;
    }
    ret--;
    b[ret] = 0;

    ret = ch_pass(argv[1], b);
    //ret = user_validate(argv[1], b);
    if (ret) {
	fprintf(stderr,"error changing password\n");
	exit(1);
    }

    exit(0);
}
