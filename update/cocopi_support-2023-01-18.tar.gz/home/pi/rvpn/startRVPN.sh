#!/bin/bash

clear

cd $HOME/rvpn

if [ -c /dev/net/tun ]; then
        echo tun interface character device exists.  Good.
        echo
else
	echo ERROR! tun interface character device does not exist.
	echo
	echo Attempting to create...
	#sudo mknod /dev/net/tun c 10 200
	echo
	echo Please try to run the script again.
	echo
	read -p "Press any key to continue to continue." -n1 -s
	exit 1
fi

if [ -f "$HOME/rvpn/rvpn.log" ]; then
	echo Previous log file exists - deleting
	sudo rm $HOME/rvpn/rvpn.log
	echo
fi

clear

echo -e "The RVPN daemon will provide Internet access to Brett" > msg.txt
echo -e "Gordon's private retro computer network." >> msg.txt
echo -e >> msg.txt
echo -e "Please make sure to apply for access before continuing." >> msg.txt
echo -e >> msg.txt
echo -e >> msg.txt
echo -e "More information about RVPN can be found at:" >> msg.txt
echo -e >> msg.txt
echo -e "http://10.8.3.1/servers.html" >> msg.txt
echo -e >> msg.txt
echo -e >> msg.txt

whiptail --title "RVPN Daemon" --textbox msg.txt 0 0
rm msg.txt

sudo rvpn

sleep 3s

# check for existance of tun0 interface

if ifconfig tun0|grep -ci 'UP' > /dev/null
then
	echo "RVPN connection is up."
	echo
	ifconfig tun0
else

	echo "RVPN connection is down."
	echo
fi

echo
read -p "Done!  Press any key to continue to continue." -n1 -s

cd $HOME/.mame

