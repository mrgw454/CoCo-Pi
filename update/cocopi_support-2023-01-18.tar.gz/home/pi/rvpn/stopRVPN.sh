clear

cd $HOME/rvpn
sudo rvpn -k

sleep 3s

if ifconfig tun0|grep -ci 'UP' > /dev/null
then
        echo "RVPN connection is up."
	echo
        ifconfig tun0
	echo
else

        echo "RVPN connection is down."
	echo
fi

echo
read -p "Done!  Press any key to continue to continue." -n1 -s

cd $HOME/.mame

