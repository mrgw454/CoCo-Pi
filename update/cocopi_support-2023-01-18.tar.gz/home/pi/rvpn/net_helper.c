/* This program is designed to help setup interfaces/routes/dhcp
   for a rvpn.

   This program receives our network address from the rvpn client on
   the commandline, and reads in a configuration file listing
   interfaces to attach to.  Two types of interfaces are listed: tap
   types, and lan types.  tap type interfaces received a /30 network,
   and lan interfaces receive a /26 network.

*/


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define WS " \t\n"
#define DEFCONFIG "net_helper.conf"

unsigned char *defconfig = DEFCONFIG;

uint32_t netaddr;
int hostbits;
int netbits;
char *taps[256];
char *lans[256];
int tapno = 0;
int lanno = 0;
int flg_down = 0;

void usage(void) {
    printf("usage: net_helper -d {netaddress} {hostbits} {netbits}\n");
    exit(1);
}

int my_system(char *s) {
    int ret = system(s);
    if (ret != 0) {
	printf("%s: ERROR %d\n", s, ret);
    }
    return ret;
}

void down(void) {
    int i;
    char buf[256];
    struct in_addr a;
    int ret;

    /* fixme: kill dhcpd */
    my_system("kill `cat dhcpd.pid`; sleep 1");
    /* delete tap addressing */
    for (i = 0; i < tapno; i++) {
	a.s_addr = htonl(netaddr + (i + 1) * 4 + 1);
	sprintf(buf, "ip addr del %s/30 dev %s\n",
		inet_ntoa(a), taps[i]);
	my_system(buf);
    }
    /* delete lan addressing */
    for (i = 0; i < lanno; i++) {
	a.s_addr = htonl(netaddr + (i + 1) * 64 + 1);
	sprintf(buf, "ip addr del %s/26 dev %s\n",
		inet_ntoa(a), lans[i]);
	my_system(buf);
    }
    exit(0);
}

int main(int argc, char *argv[]) {
    int i;
    char *e;
    FILE *f;
    char buf[256];
    int state = 0;
    int ret;
    struct in_addr a;

    /* process command line options */
    if (argc < 4) usage();

    i = 1;
    if (!strcmp(argv[1],"-d")) {
	flg_down = 1;
	i++;
    }

    netaddr = ntohl(inet_addr(argv[i++]));
    if (netaddr == INADDR_NONE) usage();

    hostbits = strtol(argv[i++], &e, 0);
    if (*e) usage();
    netbits = strtol(argv[i++], &e, 0);
    if (*e) usage();

    netaddr = netaddr & (-1 << (hostbits));

    /* read in config file */
    f = fopen(defconfig,"r");
    if (f == NULL) {
	perror(defconfig);
	exit(1);
    }
    while(1) {
	if (fgets(buf, 256, f) == NULL) break;
	if (*buf == '#') continue;
	e = strtok(buf, WS);
	while(e) {
	    if (!strcmp(e, "taps")) {
		state = 1;
		goto next;
	    }
	    if (!strcmp(e, "lans")) {
		state = 2;
		goto next;
	    }
	    switch (state) {
	    case 0:
		printf("config file error: %s\n", e);
		exit(1);
	    case 1:
		taps[tapno++] = strdup(e); break;
	    case 2:
		lans[lanno++] = strdup(e); break;
	    }
	next:
	    e = strtok(NULL, WS);
	}
    }
    fclose(f);
    /* filter inputs */
    if (tapno > 63) {
	printf("error: too many tap interfaces\n");
	exit(1);
    }
    if (lanno > 3) {
	printf("error: too many lan interfaces\n");
	exit(1);
    }

    /* tear down interface addressing? */
    if (flg_down) down();

    /* set interfaces up */
    for (i = 0; i < tapno; i++) {
	a.s_addr = htonl(netaddr + (i+1)*4 + 1);
	sprintf(buf,"ip addr add %s/30 dev %s\n",
		inet_ntoa(a), taps[i]);
	printf(buf);
	my_system(buf);
    }
    for (i = 0; i < lanno; i++) {
	a.s_addr = htonl(netaddr + (i+1)*64 + 1);
	sprintf(buf,"ip addr add %s/26 dev %s\n",
		inet_ntoa(a), lans[i]);
	printf(buf);
	my_system(buf);
    }
    /* set routes up
    a.s_addr = htonl(netaddr & (-1 << (hostbits+netbits)));
    sprintf(buf, "ip route add %s/%d dev tun0\n",
	    inet_ntoa(a), hostbits+netbits);
    ret = system(buf);
    if (ret != 0) {
	printf("%s: exit status: %d\n", buf, ret);
    } */
    /* set dhcpd up */
    f = fopen("dhcpd.conf","w");
    if (f == NULL) {
	perror("fopen");
	exit(1);
    }
    for (i = 0; i < tapno; i++) {
	a.s_addr = htonl(netaddr + (i + 1) * 4);
	fprintf(f,"subnet %s ", inet_ntoa(a));
	a.s_addr = htonl(-1 << (32 - 30));
	fprintf(f,"netmask %s {\n", inet_ntoa(a));
	a.s_addr = htonl(netaddr + (i + 1) * 4 + 1);
	fprintf(f,"\toption routers %s;\n", inet_ntoa(a));
	// fixme: pass this from rvpn?
	fprintf(f,"\toption domain-name-servers 10.8.0.1;\n");
	a.s_addr = htonl(netaddr + (i + 1) * 4 + 2);
	fprintf(f,"\trange %s;\n", inet_ntoa(a));
	fprintf(f,"\tfilename \"auto.bin\";\n}\n");
    }
    for (i = 0; i < lanno; i++) {
	a.s_addr = htonl(netaddr + (i + 1) * 64);
	fprintf(f,"subnet %s ", inet_ntoa(a));
	a.s_addr = htonl(-1 << (32 - 26));
	fprintf(f,"netmask %s {\n", inet_ntoa(a));
	a.s_addr = htonl(netaddr + (i + 1) * 64 + 1);
	fprintf(f,"\toption routers %s;\n", inet_ntoa(a));
	// fixme: pass this from rvpn?
	fprintf(f,"\toption domain-name-servers 10.8.0.1;\n");
	a.s_addr = htonl(netaddr + (i + 1) * 64 + 2);
	fprintf(f,"\trange %s ", inet_ntoa(a));
	a.s_addr = htonl(netaddr + (i + 1) * 64 + 62);
	fprintf(f,"%s;\n}\n", inet_ntoa(a));
    }
    fclose(f);
    my_system("dhcpd -cf dhcpd.conf -lf dhcpd.lease -pf dhcpd.pid &");
    exit(0);
}
