#include "user.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "unistd.h"
#include "ctype.h"
#include <openssl/conf.h>
#include <openssl/sha.h>

static FILE *f;
static char line[BUFMAX];

struct dbentry user_entry;

static void do_ssh(char *t, unsigned char *hash) {
    SHA256_CTX ctx;
    SHA256_Init(&ctx);
    SHA256_Update(&ctx, t, strlen(t));
    SHA256_Final(hash, &ctx);
}


int user_start(void) {
    /* open passwd file */
    f = fopen(PWFILE,"r");
    if (f == NULL) {
	perror("open");
	return(1);
    }
    return 0;
}

int user_next(void) {
    char *l;
    char *t;
    /* read a record */
    bzero(&user_entry, sizeof(user_entry));
    while(1) {
	l = fgets(line, BUFMAX, f);
	if (l == NULL) {
	    fclose(f);
	    return 1;
	}
	if (!isalnum(*l)) continue;
	/* put into a static dbentry */
	t = strtok(l, ":");
	if (t == NULL) continue;
	user_entry.username = t;
	t = strtok(NULL, ":");
	if (t == NULL) return 0;
	user_entry.uid = strtol(t, NULL, 0);
	t = strtok(NULL, ":");
	if (t == NULL) return 0;
	user_entry.peer = strtol(t, NULL, 0);
	t = strtok(NULL, ":\n\r ");
	if (t == NULL) return 0;
	user_entry.hash = t;
	return 0;
    }
}

static void end(void) {
    fclose(f);
    return;
}

int get_user(char *u) {
    if (user_start())
	perror("get user");
    while(!user_next()) {
	if (!strcmp(u, user_entry.username)) {
	    end();
	    return 0;
	}
    }
    return 1;
}


int user_validate(char *u, char *p) {
    unsigned char hash[32];
    unsigned char hash2[32];
    int i;
    int x;
    char b[3];
    char *ptr;

    b[2] = 0;
    strcat(p,u);
    do_ssh(p,hash);

    if (get_user(u)) return 1;

    if (strlen(user_entry.hash) != 64)
	return 1;
    ptr = user_entry.hash;
    for(i = 0; i < 32; i++) {
	b[0] = *ptr++;
	b[1] = *ptr++;
	hash2[i] = strtol(b,NULL,16);
    }
    if (!memcmp(hash,hash2,32))
	return 0;
    return 1;
}

int ch_pass(char *u, char *p) {
    int i;
    int ret;
    unsigned char hash[32];
    FILE *temp;

    strcat(p,u);
    do_ssh(p,hash);
    /* open temp file */
    temp = fopen(PWTEMP,"w");
    if (temp == NULL) {
	perror("open temp");
	exit(1);
    }

    user_start();

    while (!user_next()) {
	fprintf(temp, "%s:%d:%d:", user_entry.username,
		user_entry.uid, user_entry.peer);
	if (!strcmp(u,user_entry.username)) {
	    for (i = 0; i < 32; i++)
		fprintf(temp, "%0.2x", hash[i]);
	    fprintf(temp, "\n");
	}
	else {
	    fprintf(temp,"%s\n", user_entry.hash);
	}
    }

    fclose(temp);

    ret = unlink(PWFILE);
    if (ret) {
	perror("unlink");
	exit(1);
    }
    ret = link(PWTEMP, PWFILE);
    if (ret) {
	perror("link");
	exit(1);
    }
    unlink(PWTEMP);
}
