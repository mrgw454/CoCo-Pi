#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <fcntl.h>
#include <net/if.h>
#include <linux/if_tun.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/types.h>
#include <netdb.h>
#include <openssl/conf.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#include <openssl/sha.h>

#include "user.h"

/*
   fixme: there could be some bad array indexing still going on
   fixme: mass swizzle packets?
   fixme: add BMAC to security?
   fixme: make sure to range input from config/cmd line
   fixme: we quit if tunnel dev goes down? (restart tunnel)
   packet size checking
   fixme: filter multicast/broadcast
   fixme: how to handle user account - how to divide UID?
*/


#define MAX(a,b) (a > b ? a : b)
#define MIN(a,b) (a < b ? a : b)

#define NETNO 256              /* number of possible networks */
#define HOSTNO 1               /* number of possible hosts */
#define SERVER "play-classics.net"      /* default name of server */
#define PORT  0                /* port number */
#define DEFSRVPORT 6999        /* default public server port */
#define MAXBUF (1500+ROUTE_LEN)  /* max buffer size (ethernet + router prefix */
#define IFNAME "tun0"          /* default tunnel interface name */
#define DEFCONFIG "rvpn.conf" /* default config file name */
#define DEFNET 0x0a080000      /* default network address: 10.8.0.0 */
#define DEFUSER "ANON"
#define DEFPASS "ANON"
#define DEFANON 128

#define OP_ROUTE   2        /* an encapsulated packet to route */
#define OP_KEEP    3        /* keep alive packet */
#define OP_ADDR    4        /* set address */
#define OP_RETR    5        /* packet trace/routing info */

#define HDR_LEN   3
#define MAGIC     0x1234
#define KEEP_LEN  HDR_LEN+4+4

#define OPCODE    buf[2]
#define PADDR     *(uint32_t *)(buf+3)    /* your peer no */
#define NADDR     *(uint32_t *)(buf+7)    /* vpn network address */
#define HBITS     *(uint32_t *)(buf+11)   /* host bits */
#define NBITS     *(uint32_t *)(buf+15)   /* net/peer bits */
#define YIPADDR   *(uint32_t *)(buf+19)   /* your public ip */
#define YIPPORT   *(uint16_t *)(buf+23)   /* your public port */
#define ADDR_LEN  HDR_LEN+25              /* length of address packet */

/* ROUTE/RETR packet description */
#define DADDR     *(uint16_t *)(buf+3)   /* end destination peer */
#define SADDR     *(uint16_t *)(buf+5)   /* source peer (us) */
#define RADDR     *(uint16_t *)(buf+7)   /* last peer to relay */
#define DIADDR    *(uint32_t *)(buf+9)   /* destination peer's inet addr */
#define DPORT     *(uint16_t *)(buf+13)  /* destination peer's port no */
#define SIADDR    *(uint32_t *)(buf+15)  /* source peer's inet addr */
#define SPORT     *(uint16_t *)(buf+19)  /* source peer's port no */
#define FLAG      buf[21]                /* if zero no return packet */
#define HOPS      buf[22]                /* hop count */
#define LIST      ((uint16_t *)(buf+23)) /* array of 8 peers */
#define IV        ((uint8_t *)(buf+39))  /* AES IV of encapsulated packet */
#define ROUTE_LEN (HDR_LEN+20+16+16)     /* length of ROUTE packet */


void encrypt(void);
int decrypt(void);

/* vcon represents a peer/server connection */
struct vcon {
    struct sockaddr_in iaddr;          /* peer's transport address */
    time_t time;                       /* timer state */
    time_t lastsend;                   /* time of last sent packet */
    uint32_t next;                     /* next hop */
    int32_t cost;                     /* cost to use next hop */
    uint8_t state1;                    /* state of connection */
    uint8_t state2;                    /* substate of connection */
    uint8_t state3;                    /* stale retries */
    /* state1: */
#define  ST_UNUSED  0    /* empty */
#define  ST_PUNCH   1    /* we've started punching */
#define  ST_ACK     2    /* we've received a packet */
#define  ST_CONN    3    /* connected */
#define  ST_STALE   4    /* stale */
};

/* an dynamically allocated array of these connections
   one for each peer
*/
struct vcon *vcons = NULL;

int netdown = 1;               /* our networking has gone down flag*/
int tunfd;                     /* socket to tun from LAN */
int sockfd;                    /* socket to VPN peers/server */
unsigned char buf[MAXBUF];     /* a packet buffer */
int len;                       /* length of received packet */
uint32_t naddr;                /* our VPN network address we serve */
uint32_t paddr;                /* our VPN peer no. */
int flg_srv = 0;               /* are we the big server? */
int flg_pp = 0;                /* print packets? */
int flg_verbose = 0;           /* verbosoty level */
int flg_key = 0;               /* is key set? */
int flg_nodaemon = 0;          /* prohibit deamonizing */
int flg_kill = 0;              /* kill existing server flag */
uint32_t netno = NETNO;        /* number of networks/peers */
uint32_t hostno = HOSTNO;      /* number of possible hosts per network */
uint32_t netip;                /* IP address of the vpn network */
uint32_t netmask;              /* net mask of vpn network */
int hostbits = 8;              /* number of bits of address for hosts */
int netbits = 8;               /* number of bits of address for peers */
char *ifname = IFNAME;         /* string name of local tun interface */
int conno = 0;                 /* number of open connections */
uint32_t myip;                 /* my public IP */
uint16_t myport;               /* my public IP port */
uint32_t mypip;                /* my private IP */
uint16_t mypport;              /* my private port */
unsigned char *config = DEFCONFIG;   /* configuration file */
unsigned char key[32];
char *server = SERVER;
uint16_t port = PORT;
uint16_t sport = DEFSRVPORT;
uint32_t bindaddr = 0;
char *logname = NULL;
FILE *logfile = NULL;
//uint32_t mtu = 1500-28-ROUTE_LEN;  /* max IP header + UDP + rvpn routing */
uint32_t mtu = 1000;
char *ifup = NULL;
char *ifdown = NULL;
char *pidfile = NULL;
char *homedir = NULL;
char *username = DEFUSER;
char *password = DEFPASS;
int anon = DEFANON;

struct vcon tempcon;           /* temporary connection holder */


void myprintf(int level, char *s,...) {
    time_t t = time(NULL);
    char b[256];
    va_list ap;
    va_start(ap,s);
    if (flg_verbose >= level) {
	strftime(b, 256, "%c", gmtime(&t));
	fprintf(logfile, "[%s] ", b);
	vfprintf(logfile, s, ap);
    }
    va_end(ap);
}

void myperror(char *s) {
    myprintf(0, "%s: %s\n", s, strerror(errno));
}

void print_packet(unsigned char *buf, int len) {
    int i = 0;
    myprintf(0, "len: %d\n", len);
    while (len--) {
	fprintf(logfile, "%.2x ", *buf++);
	if(++i % 16 == 0) fprintf(logfile, "\n");
    }
    if (i % 16) fprintf(logfile,"\n");
}



void quit(void) {
    struct in_addr h;
    char buf[256];
    int ret;

    close(tunfd);
    close(sockfd);
    myprintf(0, "exiting.\n");
    h.s_addr = htonl(naddr + (paddr<<hostbits) + hostno);
    if (ifdown) {
	sprintf(buf, "%s %s %d %d", ifdown, inet_ntoa(h),
		hostbits, netbits);
	ret = system(buf);
	if (ret != 0) {
	    printf("%s: return %d\n", buf, ret);
	}
    }
    sprintf(buf, "ip tuntap del mode tun name %s", ifname);
    system(buf);
    ret = unlink(pidfile);
    exit(1);
}


void sig(int signo) {
    myprintf(0,"Caught Sig %d\n", signo);
    quit();
}

struct vcon *validate(int peer) {
    if (peer > netno || peer < 0) {
	myprintf(1, "bad peer no.\n");
	return NULL;
    }
    return vcons + peer;
}

/* fixme: consider inlining */
void apply_magic(void) {
    *(uint16_t *)buf = htons(MAGIC);
}

void forget_peer(struct vcon *v) {
    int i;
    int d;
    d = v - vcons;
    myprintf(1,"peer %d going dead\n", d);
    /* scan any next hops for this connection and void them */
    for (i = 0; i < netno; i++) {
	if (vcons[i].next == d) {
	    vcons[i].next = 0;
	    vcons[i].cost = -1;
	}
    }
    /* reset peer struct */
    bzero(v, sizeof(struct vcon));
    v->cost = -1;
    /* check if we have no potentinal peers */
    for (i = 0; i < netno; i++) {
	if (vcons[i].state1 != 0) return;
    }
    myprintf(1,"ALL peers dead: retrying seed\n");
    netdown = 1;
}


void say(struct vcon *v) {
    int ret;
    apply_magic();
    /* check vcon pointer */
    ret = v - vcons;
    if (ret > netno || ret < 0) {
	myprintf(1,"in say: peer no out of range, or not connected: %d\n", ret);
	return;
    }
    ret = sendto(sockfd, buf, len, 0,
		 (struct sockaddr *)&v->iaddr,
		 sizeof(struct sockaddr_in));
    if (ret < 0) {
	if (errno == ENETUNREACH)
	    netdown = 1;
	myperror("in say: sendto");
	forget_peer(v);
    }
}

void say_keep(struct vcon *v) {
    OPCODE = OP_KEEP;
    PADDR = htonl(paddr);
    NADDR = htonl(v->state1);
    len = KEEP_LEN;
    /* append user name and password if we need an address */
    if (!flg_srv && paddr == 0) {
	len = ROUTE_LEN;
	strcpy(buf+len, username);
	len += strlen(username) + 1;
	strcpy(buf+len, password);
	len += strlen(password) + 1;
	encrypt();
    }
    say(v);
}


void go_punch(struct vcon *v) {
    myprintf(1,"punching peer %lu %s:%u\n", v-vcons,
	     inet_ntoa(v->iaddr.sin_addr),
	     ntohs(v->iaddr.sin_port));
    v->state1 = ST_PUNCH;
    v->state2 = 0;
    v->time = time(NULL) + 1;
    say_keep(v);
}

/* fixme: consider inlining */
void connect_to(struct vcon *v, struct sockaddr_in *iaddr) {
    /* set transport address */
    memcpy(&(v->iaddr), iaddr, sizeof(struct sockaddr_in));
    /* reset DEAD timer */
    v->state3 = 0;
    /* set new slot to PUNCH and do timer */
    go_punch(v);
}

/* find local transport address */
void get_local(void) {
    struct sockaddr_in addr;
    int ret;
    int x;
    char line[256];
    char name[16];
    uint32_t dest = 1;
    uint32_t mask;
    uint16_t port;

    mypip = 0;
    mypport = 0;

    FILE *f = fopen("/proc/net/route", "r");
    struct sockaddr_in *s;
    if (f == NULL) {
	myperror("opening routing table");
	return;
    }
    fgets(line, 256, f);
    while (1) {
	ret = fscanf(f, "%s %x %*x %*x %*x %*x %*x %x %*x %*x %*x ", name, &dest, &mask);
	if (ret != 3) break;
	if (dest == 0 && mask == 0) break;
    }
    fclose(f);
    if (dest || mask) {
	myprintf(1,"Cannot find default route\n");
	return;
    }
    struct ifreq i;
    strcpy(i.ifr_name,name);
    ret = ioctl(sockfd, SIOCGIFADDR, &i);
    if (ret < 0) {
	myperror("open_socketfd: ioctl");
	return;
    }
    s = (struct sockaddr_in *)&i.ifr_addr;
    x = sizeof(struct sockaddr_in);
    ret = getsockname(sockfd, (struct sockaddr *)&addr, &x);
    if (ret < 0) {
	myperror("in open_socketfd: getsockname");
	return;
    }
    port = addr.sin_port;
    myprintf(1,"My default route on %s is at %s:%d\n", name, inet_ntoa(s->sin_addr), ntohs(port));
    mypip = s->sin_addr.s_addr;
    mypport = port;
}

void open_socketfd(void) {
    struct sockaddr_in addr;
    int ret;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
	myperror("socket");
	quit();
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(flg_srv ? sport : port);
    addr.sin_addr.s_addr = bindaddr;

    ret = bind(sockfd, (struct sockaddr *)&addr, sizeof(addr));
    if (ret < 0) {
	myperror("bind");
	quit();
    }


}

void setup_tunnel(void) {
    int ret;
    char buf[256];
    struct ifreq ifr;

    /* make a tunnel device */
    sprintf(buf, "ip tuntap add mode tun name %s", ifname);
    ret = system(buf);
    if (ret) {
	myperror("make tunnel");
	exit(1);
    }

    /* open tunnel device */
    tunfd = open("/dev/net/tun", O_RDWR);
    if (tunfd < 0) {
	myperror("open tun");
	quit();
    }
    /* configure for layer 3 tunnel, no packet information */
    memset(&ifr, 0, sizeof(ifr));
    ifr.ifr_flags = IFF_TUN | IFF_NO_PI;
    strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
    ret = ioctl(tunfd, TUNSETIFF, (void *)&ifr);
    if (ret < 0) {
	myperror("tun set");
	quit();
    }
}

/* this finalizes the local tunnel device addressing once
   we know our naddr/hostno */
void config_tunnel(void) {
    int ret;
    char buf[256];
    struct in_addr host;

    host.s_addr = htonl(naddr + (paddr<<hostbits) + hostno);
    /* configure tunnel device */
    sprintf(buf,"ip addr add %s/%d dev %s",
	    inet_ntoa(host), 32-hostbits-netbits, ifname);
    ret = system(buf);
    if (ret)
	myprintf(1,"WARNING: setting address of tunnel: %d\n", ret);
    sprintf(buf, "ip link set %s up mtu %d", ifname, mtu);
    ret = system(buf);
    if (ret)
	myprintf(1,"WARNING: seting tunnel link UP: %d\n", ret);
    /* turn off redirect messages to avoid extra traffic */
    sprintf(buf, "echo 0 > /proc/sys/net/ipv4/conf/%s/send_redirects",
	    ifname);
    ret = system(buf);
    if (ret)
	myprintf(1,"WARNING: turning off redirects on tunnel: %d\n", ret);
    /* not the end of the world here so don't quit() */
    /* exectue the interface up script */
    if (ifup) {
	sprintf(buf, "%s %s %d %d", ifup, inet_ntoa(host),
		hostbits, netbits);
	ret = system(buf);
	if (ret)
	    myprintf(1,"WARNING: executing if up script: %d\n", ret);
    }
}


/* send a routed packets to peer */
void send_to_peer(struct vcon *v) {
    OPCODE = OP_ROUTE;
    say(v);
}

/* return to send traces packet info */
void return_to_source(struct vcon *v) {
    int ret;
    /* if no connection drop it */
    if (v->state1 != ST_CONN) return;
    OPCODE = OP_RETR;
    len = ROUTE_LEN;
    say(v);
}


void replace_next(int peer, int gw, int cost) {
    struct vcon *v = validate(peer);
    if (gw == 0) cost = 99;
    myprintf(2,"replace next: %u %u %d %d\n", peer,gw,cost,v->cost);
    if (cost < v->cost || v->cost == -1) {
	v->cost = cost;
	v->next = gw;
    }
}


/* We've received a back trace packet
   this is the end result of a FLOODed ROUTE packet,
   so we may get many responses from different routes,
   and unsolicited responses from other routers grokking
   for their own routes
*/
void in_retr(void) {
    int ret;
    int i;
    int cost;
    int gw;
    int hops = HOPS;
    int src = ntohs(SADDR);
    int dest = ntohs(DADDR);
    int us;
    struct vcon *v = validate(dest);

    if (v == NULL) return;
    /* if we're the source: update our next hop and cost
       if it's less then our current next hop
     */
    if (src == paddr) {
	myprintf(2,"debug 1:\n");
	replace_next(dest, ntohs(LIST[0]), hops);
	if (v->state1 != ST_CONN){
	    v->iaddr.sin_family = AF_INET;
	    v->iaddr.sin_addr.s_addr = DIADDR;
	    myprintf(1,"*** retr: using addr: %s", inet_ntoa(v->iaddr.sin_addr));
	    if (DIADDR == 0) print_packet(buf,len);
	    v->iaddr.sin_port = DPORT;
	    v->state3 = 0;
	    go_punch(v);
	}
	return;
    }
    /* find our entry in the hop list */
    for (us = 0; us < hops; us++) {
	if (ntohs(LIST[us]) == paddr) break;
    }
    /* ??? we're not on this list */
    if (us == hops) return;
    /* snoop other hosts after us */
    cost = 2;
    gw = ntohs(LIST[us + 1]);
    for (i = us + 2; i < hops; i++) {
	myprintf(2,"debug 2: ");
	replace_next(ntohs(LIST[i]), gw, cost++);
    }
    myprintf(2,"debug 3: ");
    replace_next(dest, gw, cost);
    /* snoop other hosts before us */
    cost = us + 1;
    gw = ntohs(LIST[us - 1]);
    myprintf(2,"debug 4: ");
    replace_next(src, gw, cost--);
    for (i = 0; i < us-1; i++) {
	myprintf(2,"debug 5: ");
	replace_next(ntohs(LIST[i]), gw, cost--);
    }
    myprintf(2,"debug 6: ");
    replace_next(src, gw, us);
    /* are we last on the list? then return to src in header, not list */
    if (us == 0) return_to_source(vcons + src);
    else
    /* forward this packet to previous on list */
	return_to_source(vcons + ntohs(LIST[us-1]));
}

/* route packet to a peer
   inif = source of packet, -1 if via local tunnel
*/
void do_route(struct vcon *v, struct vcon *inif) {
    int i;
    uint16_t r;
    uint16_t x;

    RADDR = htons(paddr);
    /* if directly connected just send to the peer */
    if (v->state1 == ST_CONN) {
	myprintf(2,"relay to direct connect\n");
	send_to_peer(v);
	return;
    }
    /* if we have a next hop then send there */
    if (v->cost > -1) {
	i = rand() & 0xf;
	if (i == 1) FLAG = 1;
	if (i != 2) {
	    myprintf(2,"relay to next hop %d flag = %d\n", v->next, FLAG);
	    send_to_peer(vcons + v->next);
	    return;
	}
    }
    /* else flood it to other connections */
    myprintf(2,"from %d relay to flood\n", inif-vcons);
    FLAG = 1;
    /* start at random spot in peer array send flood to up to 3
       peers, who: aren't peer 0, are connected, aren't from
       the interface we received this on, and aren't the original
       sender of this routed packet.
    */
    i = 3;
    RAND_bytes((uint8_t *)(&r), 2);
    x = r %= netno;
    while(i) {
	v = vcons + x;
	if ((conno > 5) && x == 0) goto cont;
	if (v == inif) goto cont;
	if (v->state1 != ST_CONN) goto cont;
	if (x == ntohs(SADDR)) goto cont;
	send_to_peer(v);
	i--;
    cont:
	x = (++x) % netno;
	if (x == r) break;
    }
}


int decrypt(void) {
    int ret;
    EVP_CIPHER_CTX *ctx;
    unsigned char *out = buf + ROUTE_LEN;
    int outl = MAXBUF - ROUTE_LEN;
    unsigned char *in = out;
    int inl = len - ROUTE_LEN;
    int newlen = ROUTE_LEN;

    ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL) {
	myperror("openssl ctx_new");
	return 1;
    }

    ret = EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, IV);
    if (ret != 1) {
	myperror("openssl init");
	return 1;
    }

    ret = EVP_DecryptUpdate(ctx, out, &outl, in, inl);
    if (ret != 1) {
	myperror("dencrypt update");
	return 1;
    }
    newlen += outl;
    out += outl;
    outl = MAXBUF - ROUTE_LEN - outl;
    ret = EVP_DecryptFinal_ex(ctx, out, &outl);
    if (ret != 1) {
	myperror("dencrypt final");
	ERR_print_errors_fp(stdout);
	return 1;
    }
    len = newlen + outl;
    EVP_CIPHER_CTX_free(ctx);
    return 0;
}



void encrypt(void) {
    int ret;
    EVP_CIPHER_CTX *ctx;
    unsigned char *out = buf + ROUTE_LEN;
    int outl = MAXBUF - ROUTE_LEN;
    unsigned char *in = out;
    int inl = len - ROUTE_LEN;
    int newlen = ROUTE_LEN;


    ret = RAND_bytes(IV,16);
    if (ret != 1) {
	myperror("openssl rand");
	quit();
    }

    ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL) {
	myperror("openssl ctx_new");
	quit();
    }

    ret = EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, IV);
    if (ret != 1) {
	myperror("openssl init");
	quit();
    }

    ret = EVP_EncryptUpdate(ctx, out, &outl, in, inl);
    if (ret != 1) {
	myperror("encrypt update");
	quit();
    }
    newlen += outl;
    out += outl;
    outl = MAXBUF - ROUTE_LEN - outl;
    ret = EVP_EncryptFinal_ex(ctx, out, &outl);
    if (ret != 1) {
	myperror("encrypt final");
	ERR_print_errors_fp(stdout);
	quit();
    }
    len = newlen + outl;
    EVP_CIPHER_CTX_free(ctx);
}


/* receive incoming packets from local LAN */
void proc_tun(void) {
    int ret;
    uint32_t dest;
    uint32_t peer;
    char *ipbuf = buf + ROUTE_LEN;
    /* get awating packet */
    len = read(tunfd, ipbuf, MAXBUF - ROUTE_LEN);
    if (len < 0) {
	myperror("tun read");
	quit();
    }
    /* check if we're have a connection */
    if (conno == 0) {
	return;
    }
    /* we only forward/understand ipv4 */
    if ((ipbuf[0] & 0xf0) != 0x40) return;
    if (flg_pp) print_packet(buf, len);
    /* get it's IP*/
    dest = ntohl(*(uint32_t *)(ipbuf+16));
    /* filter out non network ip's
       gateway peer if not destined for a peer */
    /* no multicast */
    if ((dest & 0xf0000000) == 0xe0000000) {
	myprintf(2,"rejecting lan traffic: multicast forbidden %x\n", dest);
	return;
    }
    if ((dest & netmask) != netip) {
	myprintf(2,"rejecting lan traffic: not our vpn network %x\n", dest);
	return;
    }
    /* figure out the destination peer */
    peer = (dest >> hostbits) & (netno - 1);
    /* if our network then drop fixme: ? */
    if (peer == paddr) return;
    myprintf(2,"dest peer: %x %d ", dest, peer);
    /* encrypt */
    len += ROUTE_LEN;
    encrypt();
    /* reset routing info */
    HOPS = 0;
    FLAG = 0;
    DADDR = htons(peer);
    RADDR = SADDR = htons(paddr);
    DIADDR = mypip;
    DPORT = mypport;
    SIADDR = htonl(myip);
    SPORT = htons(myport);
    bzero(LIST,16);
    do_route(vcons + peer, (struct vcon *)-1);
}


void go_connected(struct vcon *v) {
    myprintf(1,"peer %lu connected\n", v - vcons);
    conno++;
    v->state1 = ST_CONN;
    v->state2 = 0;
    v->time  = time(NULL) + 15;
}

void activity(struct vcon *v) {
    if (v->state1 != ST_CONN) return;
    v->state2 = 0;
}


/* we received a hello */
/* our client doesn't know it's address */
void in_hello(struct sockaddr_in *addr) {
    int ret;
    uint32_t i;
    uint32_t unused;
    uint32_t choosen;
    uint32_t foo;
    char *user;
    char pass[1024];

    if (!flg_srv) return;
    myprintf(1,"HELLO from %s:%d\n", inet_ntoa(addr->sin_addr), ntohs(addr->sin_port));
    /* check validate user */
    decrypt();
    user = buf + ROUTE_LEN;
    strcpy(pass, user + strlen(user) + 1);
    myprintf(1,"user %s: \n", user);
    ret = user_validate(user,pass);
    if (ret)
	myprintf(1,"ERROR: bad authentication\n");
    else
	myprintf(1,"user authenticated\n");
    /* registered users: look up address in user file */
    if (ret == 0) {
	choosen = user_entry.peer;
	memcpy(&vcons[choosen].iaddr, addr, sizeof(addr));
	goto send;
    }
    /* look in our table for a matching address and return it */
    unused = 0;
    for (i = anon; i < netno; i++) {
	if (!unused && vcons[i].state1 == ST_UNUSED)
	    unused = i;
	if (!memcmp(&vcons[i].iaddr, addr, sizeof(addr))) {
	    choosen = i;
	    goto send;
	}
    }
    /* no match so alloc new address */
    memcpy(&vcons[unused].iaddr, addr, sizeof(addr));
    choosen = unused;
    if (choosen == 0) {
	myprintf(0,"ERR: out of dynamic addresses\n");
	/* fixme: do something clever here - reap old unused addresses ? */
	return;
    }
 send:
    myprintf(1,"sending ADDR %d to %s:%d\n", choosen,
	   inet_ntoa(addr->sin_addr), ntohs(addr->sin_port));
    vcons[choosen].state1 = ST_ACK;
    vcons[choosen].time = time(NULL) + 1;
    apply_magic();
    OPCODE = OP_ADDR;
    PADDR = htonl(choosen);
    NADDR = htonl(naddr);
    HBITS = htonl(hostbits);
    NBITS = htonl(netbits);
    YIPADDR = addr->sin_addr.s_addr;
    YIPPORT = addr->sin_port;
    ret = sendto(sockfd, buf, ADDR_LEN, 0,
		 (struct sockaddr *)addr, sizeof(struct sockaddr_in));
    if (ret < 0) {
	myperror("sendto2");
	quit();
    }
}

/* alloc the peer table, init it */
void alloc_table() {
    int i;
    vcons = calloc(netno, sizeof(struct vcon));
    if (vcons == NULL) {
	myprintf(0,"FATAL while allocating peer table:\n");
	myperror("calloc");
	quit();
    }
    /* start with all peers' costs at -1 */
    for (i = 1; i < netno; i++)
	vcons[i].cost = -1;
}

/* we received an address packet */
void in_addr(void) {
    struct sockaddr_in addr;
    /* if we're the server or already addressed drop it */
    if (paddr || flg_srv) return;
    paddr = ntohl(PADDR);
    naddr = ntohl(NADDR);
    hostbits = ntohl(HBITS);
    netbits = ntohl(NBITS);
    netno = (1<<netbits);
    addr.sin_addr.s_addr = YIPADDR;
    addr.sin_port = YIPPORT;
    myip = ntohl(YIPADDR);
    myport = ntohs(YIPPORT);
    myprintf(0, "Our peer no. set to %d\n", paddr);
    myprintf(0, "Our public ip %s:%d\n",
	   inet_ntoa(addr.sin_addr), myport);
    addr.sin_addr.s_addr = htonl(naddr + (paddr<<hostbits) );
    myprintf(0, "VPN net address: %s/%d\n", inet_ntoa(addr.sin_addr), 32-hostbits);
    netmask = ~((1 << (hostbits + netbits)) - 1);
    netip = ntohl(addr.sin_addr.s_addr) & netmask;
    myprintf(0, "host per peer: %d\n", (1<<hostbits));
    myprintf(0, "no of peers: %d\n", (1<<netbits));
    alloc_table();
    memcpy(vcons, &tempcon, sizeof(struct vcon));
    config_tunnel();
}

/* we received an keep alive packet */
void in_keep(struct sockaddr_in *addr) {
    uint32_t paddr = ntohl(PADDR);
    uint32_t naddr = ntohl(NADDR);
    struct vcon *v = vcons + paddr;
    myprintf(2, "KEEP from %d %d\n", paddr, naddr);
    if (paddr == 0 & flg_srv) {
	in_hello(addr);
	return;
    }
    switch (v->state1) {
    case ST_UNUSED:
	memcpy(&(v->iaddr), addr, sizeof(struct sockaddr_in));
    case ST_PUNCH:
    case ST_ACK:
	myprintf(1,"peer %d ACK\n", v - vcons);
	v->state1 = ST_ACK;
	v->state2 = 0;
	v->time = time(NULL) +1;
	if (naddr == ST_ACK || naddr == ST_CONN) {
	    go_connected(vcons + paddr);
	    say_keep(v);
	}
	break;
    case ST_CONN:
	break;
    case ST_STALE:
	return;
    }
    activity(vcons + ntohl(PADDR));
}

/* we've received a packet from socket */
void in_route(struct sockaddr_in *addr) {
    int ret;
    int i;
    int inif = ntohs(RADDR);
    uint32_t peer = ntohs(DADDR);
    struct vcon *v;
    uint32_t privaddr;
    uint16_t privport;
    uint32_t xaddr;
    uint16_t xport;

    /* check to make sure we know this IP */
    if (len < ROUTE_LEN) {
	myprintf(2, "WARNING: malformed packet from %s\n",
		 inet_ntoa(addr->sin_addr));
	return;
    }
    if (vcons[inif].iaddr.sin_addr.s_addr != addr->sin_addr.s_addr) {
	myprintf(2, "WARNING: route request from unknown IP: %s\n",
		 inet_ntoa(addr->sin_addr));
	return;
    }
    /* mark activity on this peer forwarding us this packet */
    activity(vcons + inif);
    /* if us then send to tunnel, bounce route packet back, try to connect */
    if (peer == paddr) {
	myprintf(2,"ROUTE: forward to tunnel %d\n", peer);
	if (decrypt()) return;
	ret = write(tunfd, buf+ROUTE_LEN, len-ROUTE_LEN);
	if (ret < 0) {
	    myperror("write tun");
	    quit();
	}
	if (FLAG) {
	    privaddr = DIADDR;
	    privport = DPORT;
	    /* fill in our public ip/port */
	    if (mypip && (SIADDR == htonl(myip))) {
		DIADDR = mypip;
		DPORT = mypport;
		xaddr = privaddr;
		xport = privport;
		myprintf(1,"***route: sending PRIV IP\n %x %d",
			 ntohl(mypip), ntohs(mypport) );
	    }
	    else {
		DIADDR = htonl(myip);
		DPORT = htons(myport);
		xaddr = SIADDR;
		xport = SPORT;
	    }
	    return_to_source(vcons + inif);
	    /* try to contact source peer directly */
	    v = vcons + ntohs(SADDR);
	    if (v->state1 == ST_UNUSED || v->state1 == ST_STALE) {
		v->iaddr.sin_family = AF_INET;
		v->iaddr.sin_addr.s_addr = xaddr;
		v->iaddr.sin_port = xport;
		v->state3 = 0;
		go_punch(v);
	    }
	}
	return;
    }
    /* drop if too many hops */
    if (HOPS > 7) return;
    /* scan route if we're already on table - looped route, drop it */
    for (i = 0; i < HOPS; i++)
	if (ntohs(LIST[i]) == paddr) return;
    /* record us as the new router address */
    RADDR = htons(paddr);
    /* add us to list */
    LIST[HOPS++] = htons(paddr);
    do_route(vcons + peer, vcons + inif);
}

/* receive and processing from remote routers */
void proc_sock(void) {
    int i;
    int ret;
    struct sockaddr_in addr;
    socklen_t size = sizeof(addr);

    len = recvfrom(sockfd, buf, MAXBUF, 0, (struct sockaddr *)&addr, &size);
    if (len < 0) {
	myperror("sock read");
	quit();
    }
    /* pre filter */
    if (len < 3) {
	myprintf(2,"packet too small\n");
	return;
    }
    if (buf[0] != (MAGIC >> 8) ||
	buf[1] != (MAGIC & 255)) {
	myprintf(2,"bad MAGIC\n");
	return;
    }
    if (flg_pp) print_packet(buf, len);
    switch(buf[2]) {
    case OP_ADDR:  in_addr(); break;
    case OP_KEEP:  in_keep(&addr); break;
    case OP_ROUTE: in_route(&addr); break;
    case OP_RETR:  in_retr(); break;
    }
}


int do_state(struct vcon *v) {
    int t = 0;
    int x;
    switch (v->state1) {
    case ST_ACK:
    case ST_PUNCH:
	if (v->state2++ == 10) {
	    myprintf(1,"peer %d going STALE\n", v - vcons);
	    v->state1 = ST_STALE;
	    t = 30;
	    break;
	}
	say_keep(v);
	t = 1;
	break;
    case ST_STALE:
	if (v->state3++ == 3) {
	    if (v == vcons) {
		/* fixme: do something special if peer 0 fails? */
	    }
	    forget_peer(v);
	    t = 0;
	    break;
	}
	go_punch(v);
	t = 1;
	break;
    case ST_CONN:
	if (v->state2++ == 2) {
	    myprintf(1,"TIMEOUT %lu\n", v - vcons);
	    /* mark peer as stale/unconnected */
	    conno--;
	    v->state1 = ST_STALE;
	    t = 30;
	    /* invalidate all next hops pointing to
	       this peer */
	    for(x = 0; x < netno; x++) {
		if (vcons[x].next == v - vcons) {
		    vcons[x].next = 0;
		    vcons[x].cost = -1;
		}
	    }
	    if (conno == 0) {
		myprintf(1,"No connections: retrying seed\n");
		netdown = 1;
	    }
	    break;
	}
	say_keep(v);
	t = 15;
	break;
    }
    v->time = time(NULL) + t;
    return t;
}


void do_ssh(char *t, unsigned char *hash) {
    SHA256_CTX ctx;
    SHA256_Init(&ctx);
    SHA256_Update(&ctx, t, strlen(t));
    SHA256_Final(hash, &ctx);
}


#define DELIM " \n\r"
void read_config(void) {
    int line = 0;
    FILE *f;
    char buf[1024];
    char *s;
    char *t;
    char *e;
    int ret;

    f = fopen(config, "r");
    if (f == NULL) {
	myperror("open config");
	return;
    }

    while(1) {
	line++;
	s = fgets(buf, 1024, f);
	if (!s) goto ok;
	t = strtok(s, DELIM);
	if (!t) continue;
	if (!strcmp(t,"servermode")){
	    flg_srv = 1;
	    continue;
	}
	if (!strcmp(t,"server")) {
	    t = strtok(NULL, DELIM);
	    if (!t) goto bad;
	    server = strdup(t);
	    if (!server) goto bad;
	    continue;
	}
	if (!strcmp(t,"port")) {
	    ret = strtol(strtok(NULL, DELIM), &e, 0);
	    if (*e) goto bad;
	    port = ret;
	    continue;
	}
	if (!strcmp(t,"key")) {
	    t = strtok(NULL, "\"");
	    if (!t) goto bad;
	    do_ssh(t, key);
	    flg_key = 1;
	    continue;
	}
	if (!strcmp(t,"verbose")) {
	    flg_verbose++;
	    continue;
	}
	if (!strcmp(t,"hostbits")) {
	    ret = strtol(strtok(NULL, DELIM), &e, 0);
	    if (*e) goto bad;
	    hostbits = ret;
	    continue;
	}
	if (!strcmp(t,"netbits")) {
	    ret = strtol(strtok(NULL, DELIM), &e, 0);
	    if (*e) goto bad;
	    netbits = ret;
	    continue;
	}
	if (!strcmp(t,"netaddr")) {
	    naddr = ntohl(inet_addr(strtok(NULL, DELIM)));
	    continue;
	}
	if (!strcmp(t,"bind")) {
	    bindaddr = inet_addr(strtok(NULL, DELIM));
	    continue;
	}
	if (!strcmp(t,"hostno")) {
	    ret = strtol(strtok(NULL, DELIM), &e, 0);
	    if (*e) goto bad;
	    hostno = ret;
	    continue;
	}
	if (!strcmp(t,"logfile")) {
	    logname = strdup(strtok(NULL, DELIM));
	    continue;
	}
	if (!strcmp(t,"ifup")) {
	    t = strtok(NULL, "\"");
	    if (!t) goto bad;
	    ifup = strdup(t);
	    continue;
	}
	if (!strcmp(t,"ifdown")) {
	    t = strtok(NULL, "\"");
	    if (!t) goto bad;
	    ifdown = strdup(t);
	    continue;
	}
	if (!strcmp(t,"pidfile")) {
	    t = strtok(NULL, "\"");
	    if (!t) goto bad;
	    pidfile = strdup(t);
	    continue;
	}
	if (!strcmp(t,"homedir")){
	    t = strtok(NULL, "\"");
	    if (!t) goto bad;
	    homedir = strdup(t);
	    continue;
	}
	if (!strcmp(t,"username")) {
	    t = strtok(NULL, "\"");
	    username = strdup(t);
	    continue;
	}
	if (!strcmp(t,"password")) {
	    t = strtok(NULL, "\"");
	    password = strdup(t);
	    continue;
	}
	if (!strcmp(t,"anon")) {
	    ret = strtol(strtok(NULL, DELIM), &e, 0);
	    if (*e) goto bad;
	    anon = ret;
	    continue;
	}
	if (!strcmp(t,"sport")) {
	    ret = strtol(strtok(NULL,DELIM), &e, 0);
	    if (*e) goto bad;
	    sport = ret;
	    continue;
	}
	if (!strcmp(t,"tunnel")) {
	    t = strtok(NULL, "\"");
	    ifname = strdup(t);
	    continue;
	}
	if (*t == '#') continue;
	goto bad;
    }
 bad:
    myprintf(1,"error in config file line %d:\n", line);
    myprintf(1,"\"%s\"\n", t);
 ok:
    fclose(f);
    return;
}

void print_help(int full) {
    puts("usage: rvpn -hvspnk (-h for help)");
    if (full) {
	puts("  -k  kill existing daemon\n"
	     "  -n  no daemonize\n"
	     "  -v  logging verbosity\n"
	     "  -s  server mode\n"
	     "  -p  loggin incoming packet data\n"
	     "  -h  this help"
	     );
    }
    exit(0);
}


/* look up server's IP */
/* fixme: we should do this every once in a while */
int lookup_server(struct sockaddr_in *a) {
    struct hostent *h;
    h = gethostbyname(server);
    if (h == NULL) {
	herror(server);
	return 1;
    }
    myprintf(2,"gethost: %s\n", inet_ntoa(*(struct in_addr *)h->h_addr));
    a->sin_family = AF_INET;
    a->sin_port = htons(port);
    memcpy( &a->sin_addr.s_addr, h->h_addr, sizeof(h->h_addr));
    return 0;
}

int reconnect(void) {
    struct sockaddr_in addr;

    myprintf(1,"attempting reconnect\n");
    /* try to contact master server */
    if (!flg_srv ) {
	if(lookup_server(&addr))
	    return 1;
	addr.sin_port = htons(sport);
	connect_to(vcons + 0, &addr);
    }
    else {
	if (!lookup_server(&addr))
	    myip = ntohl(addr.sin_addr.s_addr);
	myport = sport;
	paddr = 0;
	config_tunnel();
    }
    return 0;
}

int main(int argc, char *argv[]) {
    int ret;
    int i;
    struct vcon *v;
    FILE *f;

    ret = setuid(0);
    if (ret < 0) {
      perror("cannot set root");
    }
    
    logfile = stdout;

    signal(SIGINT, sig);
    signal(SIGTERM, sig);

    /* process cmd line */
    while(1) {
	ret = getopt(argc, argv, "hvspnk");
	if (ret < 0) break;
	switch (ret) {
	case 'v':
	    flg_verbose++;
	    break;
	case 's':
	    flg_srv = 1;
	    break;
	case 'p':
	    flg_pp = 1;
	    break;
	case 'n':
	    flg_nodaemon = 1;
	    break;
	case 'k':
	    flg_kill = 1;
	    break;
	case 'h':
	    print_help(1);
	default:
	case '?':
	    print_help(0);
	}
    }

    /* process config file */
    read_config();

    /* change to home dir */
    if (homedir) {
	ret = chdir(homedir);
	if (ret) {
	    myperror("Change Directory");
	}
    }

    /* kill existing server */
    if (flg_kill) {
	char buf[256];
	sprintf(buf,"kill -15 `cat %s`", pidfile);
	ret = system(buf);
	if (ret != 0)
	    myprintf(0, "%s: returned %d\n", buf, ret);
	exit(ret);
    }

    /* quit if no key is set */
    if (!flg_key) {
	myprintf(0,"Quit: no key set\n");
	quit();
    }

    /* set logfile */
    logfile = fopen(logname, "a");
    if (logfile == NULL) {
	myprintf(0, "Opening log file: ");
	myperror("open");
	logfile = stdout;
    }
    setlinebuf(logfile);

    myprintf(0,"Starting Peer...\n");

    /* if we're the server, then alloc our peer table now */
    if (flg_srv)
	alloc_table();
    else {
	netno = 1;
	vcons = &tempcon;
    }

    /* set up random */
    while (!RAND_poll());
    /* setup our tunnel - don't UP it or assign addresses yet */
    setup_tunnel();
    /* Become a deamon */
    if (!flg_nodaemon) {
	ret = daemon(1, 0);
	if (ret < 0)
	    myperror("Cannot deamonize");
    }
    /* write our PID file here */
    f = fopen(pidfile, "w");
    if (f) {
	fprintf(f,"%d\n", getpid());
	fclose(f);
    }

    /* select on local net and udp link to peers/server */
    fd_set rds;
    while(1){
	int i;
	struct timeval to;
	time_t t;
	int a,b;

	/* if our network connection has gone down
	   retry connection */
	if (netdown) {
	    conno = 0;
	    if (vcons != &tempcon && !flg_srv) {
		free(vcons);
		vcons = &tempcon;
		netno = 1;
		paddr = 0;
	    }
	    close(sockfd);
	    open_socketfd();
	    do{
		get_local();
		if (mypip == 0) sleep(5);
	    } while(mypip == 0);
	    while (netdown) {
		while (mypip == 0)
		get_local();
		netdown = reconnect();
		if (netdown) sleep(5);
	    }
	}

	/* calculate minimum select sleep time while
	   doing stuff if any connection's timer has expired */
	a = 10;
	t = time(NULL);
	for (i = 0; i < netno; i++) {
	    if (vcons[i].state1 && vcons[i].time) {
		b = vcons[i].time - t;
		if (b <= 0) b = do_state(vcons + i);
		if (b < a) a = b;
	    }
	}
	to.tv_usec = 0;
	to.tv_sec = a;
	FD_ZERO(&rds);
	FD_SET(sockfd, &rds);
	FD_SET(tunfd, &rds);
	/* select until something happens */
	ret = select( MAX(sockfd,tunfd)+1, &rds, NULL, NULL, &to);
	if (ret < 0) {
	    myperror("select");
	    quit();
	}
	/* do something on input */
	if (FD_ISSET(sockfd, &rds))
	    proc_sock();
	if (FD_ISSET(tunfd, &rds))
	    proc_tun();
    }
}
