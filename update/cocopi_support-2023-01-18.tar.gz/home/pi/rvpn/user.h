#define PWFILE "passwd"
#define PWTEMP "passwd.tmp"


#define BUFMAX 1024

struct dbentry {
    char *username;
    int uid;
    int peer;
    char *hash;
};

//this is an output
extern struct dbentry user_entry;

// function return 0 on OK, 1 on error

// start iterating over passwd file
int user_start(void);
// fill user_entry with next entry
int user_next(void);
// fill user_entry with user matching u
int get_user(char *u);
// change password for user u to p
int ch_pass(char *u, char *p);
// validate a user/pass combo
int user_validate(char *u, char *p);
