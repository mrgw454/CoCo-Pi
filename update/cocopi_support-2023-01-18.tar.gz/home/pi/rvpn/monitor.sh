#!/bin/sh
while :
do
mosquitto_pub -h 10.8.0.1 -p 6880 -t beretta/hosts/lappy/up -m 1 -r ;
mosquitto_sub -h 10.8.0.1 -p 6880 --will-topic beretta/hosts/lappy/up --will-payload 0 --will-retain -t beretta/hosts/lappy/up >/dev/null ;
done
