#!/bin/sh
while :
do
    mosquitto_pub -p 6880 -h 10.8.0.1 -t beretta/hosts/ren/cpu -m `cat /proc/loadavg | awk '1 {print $2}'`;
    mosquitto_pub -p 6880 -h 10.8.0.1 -t beretta/hosts/ren/df -m `df / | awk '$6 == "/" {print $5}' | cut -c 1,2`;
	sleep 15;
done

