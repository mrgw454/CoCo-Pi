#!/bin/sh
python3 -m http.server --cgi 6502 &

