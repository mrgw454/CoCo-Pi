action plan saturday 1/14/23

* untar this zip to ron's support computer (RON).
* untar this zip to the test cocopi (COCOPI).
* on COCOPI:
       run client/start.sh
* on RON:
       * run ron/start.sh
       * url to: 10.8.0.1:6502
       * click "turn it on", it'll return a magic key.
       * url to localhost:6502
       * click "turn it on", it'll ask for the magic key.
* on COCOPI:
       * url to localhost:6502
       * click "turn it on", it'll ask for the magic key.
* on Fred:
       * A web server is running (temporarily) on rvpn host 10.8.0.1:6502.

if this works, RON will have a ip address of 10.9.0.1, and COCOPI
should have address of 10.9.0.2.

