!#/bin/bash

clear

echo Stopping RVPN support network...
cd $HOME/cocopi_support/client
lynx http://localhost:6502
kill -9 `pgrep -f 6502`
echo
cd $HOME/.mame

read -p "Press any key to continue... " -n1 -s
