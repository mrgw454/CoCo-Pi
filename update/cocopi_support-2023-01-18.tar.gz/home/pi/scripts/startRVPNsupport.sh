!#/bin/bash

clear

echo Starting RVPN support network...
cd $HOME/cocopi_support/client
./start.sh
sleep 3
lynx http://127.0.0.1:6502
echo
cd $HOME/.mame

read -p "Press any key to continue... " -n1 -s

