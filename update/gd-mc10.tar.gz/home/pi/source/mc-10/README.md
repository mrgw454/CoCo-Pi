MC-10 Javascript Emulator (cassette branch)
===========================================

This is an experimental extension of Mike Tinnes' browser-based emulator of the TRS80 MC-10 color microcomputer, hosted at http://mc-10.com

Cassette loading (CLOAD, CLOADM, CLOAD*) is supported by patching ROM and reading to and from .C10 files.  Audio .WAV files may additionally be read.  An additional patch allows for text files to be entered into the console read routine of Microcolor BASIC.  

![alt tag](http://upload.wikimedia.org/wikipedia/commons/thumb/5/59/TRS-80_MC-10_Microcomputer.jpg/250px-TRS-80_MC-10_Microcomputer.jpg)

